package lab.sql.spark.warehouse
 
/**
 * 
 
  
  1. Spark SQL Shell 연결.... 
  
  - # ./bin/spark-sql --master spark://CentOS7-14:7077
  
  - # jps		//--SparkSubmit....
  
  - http://192.168.56.114:4040 (=> SparkSQL::192.168.56.114 application UI)
  
  - spark-sql> show databases;
  
  - spark-sql> show tables;
  
  - spark-sql> CREATE TABLE IF NOT EXISTS src (key INT, value STRING);
   
  - spark-sql> LOAD DATA LOCAL INPATH 'examples/src/main/resources/kv1.txt' INTO TABLE src;	//--hive field default delimiter '\001'.... ^A(ctrl-a)....
  
  - spark-sql> SELECT * FROM src;
  
  - spark-sql> SELECT COUNT(*) FROM src;
  
  - spark-sql> SELECT key, value FROM src WHERE key < 10 ORDER BY key;
  
  - spark-sql> quit;
  
  - # ls -al ./spark-warehouse/src
  
  - # ./bin/spark-sql --master spark://CentOS7-14:7077	//=> <spark_home>/conf/log4j.properties 로그 레벨 수정 가능.... (ex. log4j.rootCategory=WARN, console)
  
  - spark-sql> SELECT * FROM src;
  
  - spark-sql> SELECT COUNT(*) FROM src;
  
  - spark-sql> LOAD DATA LOCAL INPATH 'examples/src/main/resources/kv1.txt' INTO TABLE src;
  
  - spark-sql> SELECT COUNT(*) FROM src;
  
  - spark-sql> quit;
  
  - # ls -al ./spark-warehouse/src
  
  
  
  2. Thrift JDBC/ODBC Server 시작....
  
  - # ./sbin/start-thriftserver.sh --master spark://CentOS7-14:7077
  
  - # jps		//--SparkSubmit....
  
  - http://192.168.56.114:4040 (=> Thrift JDBC/ODBC Server application UI)
  
  
  
  3. beeline 연결....	=> beeline "2개 이상" 연결....
  
  - # ./bin/beeline
  
  - # jps		//--BeeLine....
  
  - beeline> !connect jdbc:hive2://CentOS7-14:10000
     Enter username for jdbc:hive2://CentOS7-14:10000: kikang		//--kikang2, kikang3 등 username 다르게 입력....
     Enter password for jdbc:hive2://CentOS7-14:10000:							//--공백('') 입력 => 그냥 엔터키....
     
  - 웹 UI "JDBC/ODBC Server" 탭 세션 정보 확인....
  
  0: jdbc:hive2://CentOS7-14:10000> select * from src;
  
  0: jdbc:hive2://CentOS7-14:10000> select count(*) from src;
  
  0: jdbc:hive2://CentOS7-14:10000> LOAD DATA LOCAL INPATH 'examples/src/main/resources/kv1.txt' OVERWRITE INTO TABLE src;
  
  0: jdbc:hive2://CentOS7-14:10000> select count(*) from src;
  
  0: jdbc:hive2://CentOS7-14:10000> CREATE TABLE IF NOT EXISTS src2 (key2 INT, value2 STRING);
  
  0: jdbc:hive2://CentOS7-14:10000> INSERT OVERWRITE TABLE src2 SELECT DISTINCT key, value FROM src WHERE key < 10;
  
  0: jdbc:hive2://CentOS7-14:10000> select * from src2;
  
  0: jdbc:hive2://CentOS7-14:10000> !quit
  
  - # jps
  
  - # ls -al ./spark-warehouse/src
  
  - # ls -al ./spark-warehouse/src2
    
  
    
  4. Thrift JDBC/ODBC Server 종료....
  
  - # ./sbin/stop-thriftserver.sh
  
  - # jps
  
  
  
  5. Spark SQL Shell 연결.... 
  
  - # ./bin/spark-sql  --master spark://CentOS7-14:7077
  
  - spark-sql> SELECT COUNT(*) FROM src;
  
  - spark-sql> SELECT * FROM src2;
  
  - spark-sql> truncate table src2;
  
  - # ls -al ./spark-warehouse/src2
  
  - spark-sql> drop table src2;
  
  - # ls -al ./spark-warehouse
  
  - spark-sql> quit;
  
  
  
  6. Thrift JDBC/ODBC Server 시작....
  
  - # ./sbin/start-thriftserver.sh --master spark://CentOS7-14:7077
  
  - # jps		//--SparkSubmit....
  
  - http://192.168.56.114:4040 (=> Thrift JDBC/ODBC Server application UI)
  
   
   
  7. SQuirreL SQL Client 3.7.1 설치 및 실행....
  
  - http://squirrel-sql.sourceforge.net/
  
  - 좌측 Menu > Download and Installation > Plain zips the latest release for Windows/Linux/MacOS X/others > squirrelsql-3.7.1-standard.zip (최신 버전은 squirrelsql-3.9.1-standard.zip....)
  
  - squirrelsql-3.7.1-standard.zip 압축 풀기.... + "squirrelsql-3.7.1-standard" 디렉토리 root 경로 바로 아래로 move.... (ex. D:\squirrelsql-3.7.1-standard) 
  
  - squirrel-sql.bat (squirrel-sql.sh) 실행
  
  - SQuirreL SQL Client 에서 좌측 Drivers 탭 클릭
  
  - 플러스(+) 아이콘 클릭 > Add Driver 팝업
  
  - 다음값 입력
     Name => Spark Thrift Server
     Example URL => jdbc:hive2://192.168.56.114:10000
     Extra Class Path => (All the jar files of your Spark distribution) (ex. C:\eclipse\workspace\Spark2.4.3_Edu_Lab\spark-2.4.3-bin-hadoop2.7\jars 아래 모든 jars....)
     Class Name	=> org.apache.hive.jdbc.HiveDriver
     
  - SQuirreL SQL Client 에서 좌측 Aliases 탭 클릭
  
  - 플러스(+) 아이콘 클릭 > Add Alias 팝업
  
  - 다음값 입력
     Name => Spark SQL
     Driver => Spark Thrift Server (콤보 선택)
     URL => jdbc:hive2://192.168.56.114:10000 (그대로 유지)
     User Name => kikang
     Password => 공백 (그대로 유지)
  
  - Connect 시도 
  
  - SQL 탭 클릭
  
  - SQL 창> show databases;
  
  - SQL 창> show tables;
  
  - SQL 창> select count(*) from src;
  
  - SQL 창> LOAD DATA LOCAL INPATH 'examples/src/main/resources/kv1.txt' INTO TABLE src;
  
  - SQL 창> select count(*) from src;
 
  
  
    
 * 
 */
object SparkShell {
  
}