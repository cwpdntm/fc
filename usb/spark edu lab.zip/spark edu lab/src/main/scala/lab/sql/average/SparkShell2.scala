package lab.sql.average

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}

/**
 * 
 
 
 1. Spark Shell 연결.... Spark SQL for Window....
  
  - # ./bin/spark-shell --master spark://CentOS7-14:7077
  
  - //--정형 데이터(JSON)....
  - scala> val people = spark.read.json("examples/src/main/resources/people.json")
  - scala> people.createOrReplaceTempView("people")
  - scala> spark.sql("SELECT name, avg(age) FROM people GROUP BY name").show
 * 
 */
object SparkShell2 {
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    //--비정형 데이터(TEXT)....
    val peopleFile = "src/main/resources/people.info"
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("AverageSQL")
      .config("spark.sql.shuffle.partitions", 4)    //--spark.sql.shuffle.partitions: 4 => Default: 200.... Configures the number of partitions to use when shuffling data for joins or aggregations....
//    .config("spark.sql.shuffle.partitions", 2)    //--spark.sql.shuffle.partitions: 2 => Default: 200.... Configures the number of partitions to use when shuffling data for joins or aggregations....      
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames
    import spark.implicits._
    
    val people = spark
      .read  //--DataFrameReader....
      .textFile(peopleFile)  //--Dataset[String]....
      .map { x => x.split("\t") }  //--이름(name)과 나이(age) 탭("\t")으로 구분.... Array[name, age]
      .map { x => (x(0), x(1)) }   //--(name, age) 튜플 생성....                             
//    .toDF()  //--columns: [_1, _2]....
//    .toDS()
      .toDF("name", "age")    //--컬럼명 지정....
      
    people.createOrReplaceTempView("people")
    spark
      .table("people")
      .printSchema()
    
    spark
      .sql("SELECT name, avg(age) as avg_age FROM people GROUP BY name")
      .toDF("name2", "avg_age2")  //--컬럼명 변경....
      .show
    
      
    while(true) {Thread.sleep(10000)}  //--for debug....
    
    /*
     * Web UI (http://localhost:4043/) 확인.... SparkShell vs. SparkShell2(.config("spark.sql.shuffle.partitions", 4) 설정)....
     * - Job 개수.... (vs. SparkShell) => 2개.... (vs. SparkShell는 5개) => why 2개????
     * - Stage 개수.... (vs. SparkShell) 
     * - Task 개수.... (vs. SparkShell) => 2개(1개 + 1개) + 3개 => 1개(첫번째 Stage) + 4개(두번째 Stage) => 4개???? => "spark.sql.shuffle.partitions" 설정을 4로 세팅.... 
     * - Shuffle File 사이즈.... (vs. SparkShell) => 후속 Stage의 Shuffle Read가 없는, 놀고 있는 Stage 존재하지 않음....
     */
      
    /*
     * To-Do.... RDD로 읽어서 DataFrame(Dataset)으로 변경하여 처리 vs. 처음부터 DataFrame(Dataset)으로 읽어서 처리....
     * spark.sparkContext.textFile(peopleFile) vs. spark.read.textFile(peopleFile)
     * - Stage 내 Operation....
     * - Shuffle File 사이즈.... => Shuffle File 사이즈도 차이나지만 Input 사이즈 자체도 차이가 남????
     */   
      
    spark.stop()
  }
}