package lab.sql.jdbc.mysql.parallelism

/**
 * 
 1. MySQL 설치 on CentOS7....
  - # yum install -y http://dev.mysql.com/get/mysql-community-release-el7-5.noarch.rpm
  - # yum install -y mysql-community-server
  - # systemctl start mysqld
  - # systemctl status mysqld.service
  - # systemctl enable mysqld
 
 
 2. 원격접속 허용(root계정 모든 IP 허용).... + Table 생성 및 Data 추가....
  - # cd /usr/bin //--불필요....
  - # mysql
  - mysql> SELECT Host,User,Password FROM mysql.user;
  - mysql> INSERT INTO mysql.user (host, user, password, ssl_cipher, x509_issuer, x509_subject) VALUES ('%','root',password(''),'','','');
  - mysql> GRANT ALL PRIVILEGES ON *.* TO 'root'@'%';
  - mysql> FLUSH PRIVILEGES;
  - mysql> show databases;
  - mysql> use mysql;
  - mysql> DROP TABLE IF EXISTS projects_parallelism;
  - mysql> 
CREATE TABLE projects_parallelism (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255),
  website varchar(255),
  manager varchar(255),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
  - mysql> describe projects_parallelism;
  - mysql> truncate projects_parallelism;
  - mysql> 
INSERT INTO projects_parallelism (name, website, manager) VALUES ('Apache Spark', 'http://spark.apache.org', 'Michael');
INSERT INTO projects_parallelism (name, website, manager) VALUES ('Apache Hive', 'http://hive.apache.org', 'Andy');
INSERT INTO projects_parallelism VALUES (DEFAULT, 'Apache Kafka', 'http://kafka.apache.org', 'Justin');
INSERT INTO projects_parallelism VALUES (DEFAULT, 'Apache Flink', 'http://flink.apache.org', 'Michael');
	- mysql> 
INSERT INTO projects_parallelism (name, website, manager) SELECT name, website, manager FROM projects_parallelism;
INSERT INTO projects_parallelism (name, website, manager) SELECT name, website, manager FROM projects_parallelism;
INSERT INTO projects_parallelism (name, website, manager) SELECT name, website, manager FROM projects_parallelism;
INSERT INTO projects_parallelism (name, website, manager) SELECT name, website, manager FROM projects_parallelism;
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|       64 |       1 |      89 |
+----------+---------+---------+
  - mysql> SELECT * FROM projects_parallelism;


 3. MySQL JDBC Driver download.... + upload....
  - https://dev.mysql.com/downloads/connector/j/
  - Platform Independent (Architecture Independent), ZIP Archive > Download > No thanks, just start my download.
  - unzip mysql-connector-java-5.1.39.zip
  - upload mysql-connector-java-5.1.39-bin.jar to CentOS7-14:/kikang/spark-2.4.3-bin-hadoop2.7
 
 
 4. MySQL SQL Query Log Check....
  - mysql> show variables like 'general%';
+------------------+-------------------------------+
| Variable_name    | Value                         |
+------------------+-------------------------------+
| general_log      | OFF                           |
| general_log_file | /var/lib/mysql/CentOS7-14.log |
+------------------+-------------------------------+

  - mysql> set global general_log=on;
  
  - mysql> show variables like 'general%';
+------------------+-------------------------------+
| Variable_name    | Value                         |
+------------------+-------------------------------+
| general_log      | ON                            |
| general_log_file | /var/lib/mysql/CentOS7-14.log |
+------------------+-------------------------------+

  - # tail -f /var/lib/mysql/CentOS7-14.log		//--tail로 바로 sql 확인....
  - # vi /var/lib/mysql/CentOS7-14.log				//--필요시 vi로 log 파일 확인....
  
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
  - tail을 통해 SQL Log 확인....


 5. Spark Shell 연결....
  - # ./bin/spark-shell --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077	 //=> executor 1개 구동....
  - # ./bin/spark-shell --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077 --executor-memory 900m --executor-cores 1 --total-executor-cores 2 --name kikang_spark_shell4_parallelism //=> executor 2개 구동.... + executor 별 memory, core 지정.... + App Name 지정....
  - scala> 
//--"numPartitions" => The 'maximum number' of partitions that can be used for parallelism in table 'reading' and 'writing'. This also determines the maximum number of concurrent JDBC connections. If the number of partitions to write exceeds this limit, we decrease it to this limit by calling coalesce(numPartitions) before writing.
//--"partitionColumn", "lowerBound", "upperBound" => These options must 'all' be specified if any of them is specified. In addition, 'numPartitions' must be specified. They describe how to partition the table when 'reading' in parallel from multiple workers. partitionColumn must be a 'numeric', 'date', or 'timestamp' column from the table in question. Notice that lowerBound and upperBound are just used to decide the partition stride, not for filtering the rows in table. So all rows in the table will be partitioned and returned. This option applies only to 'reading'.
val df_parallelism = spark.
	read.
  format("jdbc").
  option("url", "jdbc:mysql://CentOS7-14:3306/mysql").
  option("driver", "com.mysql.jdbc.Driver").
  option("dbtable", "projects_parallelism").
  option("user", "root").
  option("password", "").
  option("numPartitions", 5).	//--"numPartitions" => For 'reading' and 'writing'.... The 'maximum number' of partitions....
  option("partitionColumn", "id").	//--"partitionColumn" => Only for 'reading'.... must be a 'numeric', 'date', or 'timestamp' column type....
  option("lowerBound", 10).	//--"lowerBound" => Only for 'reading'.... just used to decide the partition stride....
  option("upperBound", 80).	//--"upperBound" => Only for 'reading'.... just used to decide the partition stride....
  load()	//=> spark_home/work/app_home/executor_id 경로내 JDBC 드라이버 jar 파일 존재여부 확인....아직 executor에서는 JDBC 드라이버 jar 파일이 필요없음....
  - scala> df_parallelism.printSchema	//=> "jdbc" 포맷으로 읽어온 DataFrame의 스키마정보는 Spark Driver에서 읽어온 것임....
  - scala> df_parallelism.show(false)	//=> spark_home/work/app_home/executor_id 경로내 JDBC 드라이버 jar 파일 존재여부 확인....실제 구동(Action 실행)될 때 필요한 jar 파일 가져옴....각 executor에서 DB로부터 데이터를 읽어오기 위해 JDBC 드라이버 jar 파일을 Spark Driver로부터 가져옴....  
  - scala> df_parallelism.show(5, false)					//--Driver UI > SQL > Completed Queries > Description 링크 > SQL DAG 내 number of output rows 개수 + numPartitions 값 확인 > Succeeded Jobs의 실제 Task 개수 확인....
  - scala> df_parallelism.show(30, false)					//--Driver UI > SQL > Completed Queries > Description 링크 > SQL DAG 내 number of output rows 개수 + numPartitions 값 확인 > Succeeded Jobs의 실제 Task 개수 확인....
  - scala> df_parallelism.show(50, false)					//--Driver UI > SQL > Completed Queries > Description 링크 > SQL DAG 내 number of output rows 개수 + numPartitions 값 확인 > Succeeded Jobs의 실제 Task 개수 확인....
  - scala> df_parallelism.show(500, false)				//--Driver UI > SQL > Completed Queries > Description 링크 > SQL DAG 내 number of output rows 개수 + numPartitions 값 확인 > Succeeded Jobs의 실제 Task 개수 확인....
  - scala> df_parallelism.count()									//--Driver UI > SQL > Completed Queries > Description 링크 > SQL DAG 내 number of output rows 개수 + numPartitions 값 확인 > Succeeded Jobs의 실제 Task 개수 확인....
  
  
  6. Parallelism on READ....   
  - scala> df_parallelism.show(500, false)				//--쿼리 5개????   
  - scala> df_parallelism.show(5, false)					//--쿼리 1개????  
  - scala> df_parallelism.count()									//--쿼리 5개????   
  - scala> 
val df_no_parallelism = spark.
	read.
  format("jdbc").
  option("url", "jdbc:mysql://CentOS7-14:3306/mysql").
  option("driver", "com.mysql.jdbc.Driver").
  option("dbtable", "projects_parallelism").
  option("user", "root").
  option("password", "").
//option("numPartitions", 5).
//option("partitionColumn", "id").
//option("lowerBound", 10).
//option("upperBound", 8).
  load()
  - scala> df_no_parallelism.printSchema	//=> "jdbc" 포맷으로 읽어온 DataFrame의 스키마정보는 Spark Driver에서 읽어온 것임....  
  - scala> df_no_parallelism.show(500, false)			//--쿼리 1개????		//--Driver UI > SQL > Completed Queries > Description 링크 > SQL DAG 내 number of output rows 개수 확인 > Succeeded Jobs의 실제 Task 개수 확인....
  - scala> df_no_parallelism.show(5, false)				//--쿼리 1개????  
  - scala> df_no_parallelism.count()							//--쿼리 1개???? 


 7. Parallelism on WRITE....   
  - scala> 
val prop: java.util.Properties = new java.util.Properties()
prop.setProperty("user", "root")
prop.setProperty("password", "")
prop.setProperty("driver", "com.mysql.jdbc.Driver")
    
    
  - #01. 'Parallel READ' + 'Parallel WRITE'.... (is OK????)	=> Task 개수 '5'.... 'READ 쿼리 + WRITE 실행'이 5개로 병렬 처리.... => WRITE에 의해 입력된 값이 다른 Task의 READ 쿼리(... WHERE `id` >= 66)에 조회되어 원치 않는 결과 발생????
  - scala> df_parallelism.rdd.partitions.length
  - scala> df_parallelism.rdd.getNumPartitions
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert....
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|       64 |       1 |      89 |
+----------+---------+---------+
  - scala> 
df_parallelism.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Append).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_parallelism", prop)
  - Driver UI > SQL > Completed Queries > Description 링크 > Succeeded Jobs의 실제 Task 개수 확인....
  - tail을 통해 SQL Log 확인.... 
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;		//--개수가 이상함????
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|      160 |       1 |     216 |
+----------+---------+---------+
  
  
  - #02. 'Single READ' + 'Single WRITE'.... (OK!!!!) => Task 개수 '1'....
  - scala> df_no_parallelism.rdd.partitions.length
  - scala> df_no_parallelism.rdd.getNumPartitions
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert....
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|      160 |       1 |     216 |
+----------+---------+---------+
  - scala> 
df_no_parallelism.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Append).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_parallelism", prop)
  - Driver UI > SQL > Completed Queries > Description 링크 > Succeeded Jobs의 실제 Task 개수 확인....
  - tail을 통해 SQL Log 확인.... 
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;		//--개수 OK!!!!
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|      320 |       1 |     376 |
+----------+---------+---------+
  
  
  - #03. 'Single READ' + 'Parallel WRITE'.... (OK!!!!) => Task 개수 '1' + '3'....
  - scala> val df_no_parallelism_03 = df_no_parallelism.repartition(3)
  - scala> df_no_parallelism_03.rdd.partitions.length
  - scala> df_no_parallelism_03.rdd.getNumPartitions
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert....
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|      320 |       1 |     376 |
+----------+---------+---------+
  - scala> 
df_no_parallelism_03.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Append).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_parallelism", prop)
  - Driver UI > SQL > Completed Queries > Description 링크 > Succeeded Jobs의 실제 Task 개수 확인....
  - tail을 통해 SQL Log 확인.... 
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;		//--개수 OK!!!!
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|      640 |       1 |     696 |
+----------+---------+---------+
  
  
  - #04. 'Parallel READ' + 'Single WRITE'(by 'coalesce').... (OK!!!!)	=> Task 개수 '1'.... READ 쿼리 5개 순차 처리 후 WRITE 실행....
  - scala> val df_parallelism_01 = df_parallelism.coalesce(1)		//--by coalesce()....
  - scala> df_parallelism_01.rdd.partitions.length
  - scala> df_parallelism_01.rdd.getNumPartitions
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert....
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|      640 |       1 |     696 |
+----------+---------+---------+
  - scala> 
df_parallelism_01.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Append).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_parallelism", prop)
  - Driver UI > SQL > Completed Queries > Description 링크 > Succeeded Jobs의 실제 Task 개수 확인....
  - tail을 통해 SQL Log 확인.... 
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;		//--개수 OK!!!!
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|     1280 |       1 |    1336 |
+----------+---------+---------+
  
  
  - #05. 'Parallel READ' + 'Single WRITE'(by 'repartition').... (OK!!!!)	=> Task 개수 '5' + '1'.... READ 쿼리 5개 병렬 처리 후 WRITE 실행....
  - scala> val df_parallelism_001 = df_parallelism.repartition(1)		//--by repartition()....
  - scala> df_parallelism_001.rdd.partitions.length
  - scala> df_parallelism_001.rdd.getNumPartitions
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert....
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|     1280 |       1 |    1336 |
+----------+---------+---------+
  - scala> 
df_parallelism_001.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Append).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_parallelism", prop)
  - Driver UI > SQL > Completed Queries > Description 링크 > Succeeded Jobs의 실제 Task 개수 확인....
  - Task별 'Shuffle Write Size / Records' 값 확인 => Task별 치우침 확인.... => "lowerBound", "upperBound" 재조정 필요....
  - tail을 통해 SQL Log 확인.... 
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;		//--개수 OK!!!!
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|     2560 |       1 |    2616 |
+----------+---------+---------+


  - #06. Parallel READ + Parallel WRITE(by 'coalesce').... => coalesce(3)이라면???? (is OK????)	=> Task 개수 '3'.... 'READ 쿼리 + WRITE 실행'이 3개로 병렬 처리.... => WRITE에 의해 입력된 값이 다른 Task의 READ 쿼리(... WHERE `id` >= 66)에 조회되어 원치 않는 결과 발생????
  - scala> val df_parallelism_003 = df_parallelism.coalesce(3)		//--by coalesce()....
  - scala> df_parallelism_003.rdd.partitions.length
  - scala> df_parallelism_003.rdd.getNumPartitions
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert....
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|     2560 |       1 |    2616 |
+----------+---------+---------+
  - scala> 
df_parallelism_003.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Append).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_parallelism", prop)
  - Driver UI > SQL > Completed Queries > Description 링크 > Succeeded Jobs의 실제 Task 개수 확인....
  - tail을 통해 SQL Log 확인.... 
  - mysql> SELECT count(*), min(id), max(id) FROM projects_parallelism;		//--개수가 이상함????
+----------+---------+---------+
| count(*) | min(id) | max(id) |
+----------+---------+---------+
|     5392 |       1 |    5448 |
+----------+---------+---------+
    
  
  
 * 
 */
object SparkShell {
  
}