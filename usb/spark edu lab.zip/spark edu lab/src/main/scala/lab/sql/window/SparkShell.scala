package lab.sql.window

/**
 * 
 
 
 1. Spark Shell 연결.... Spark SQL for Window....
  
  - # ./bin/spark-shell --master spark://CentOS7-14:7077
  
  - //--Building the customer DataFrame....
  - scala> 
val customers = sc.
	parallelize(
		List(
			("Alice", "2016-05-01", 50.00), 
			("Alice", "2016-05-03", 45.00), 
			("Alice", "2016-05-04", 55.00), 
			("Bob", "2016-05-01", 25.00), 
			("Bob", "2016-05-04", 29.00), 
			("Bob", "2016-05-06", 27.00)
		)
	).
	toDF("name", "date", "amountSpent")
	
  - scala> customers.show
  	
  	+-----+----------+-----------+
    | name|      date|amountSpent|
    +-----+----------+-----------+
    |Alice|2016-05-01|       50.0|
    |Alice|2016-05-03|       45.0|
    |Alice|2016-05-04|       55.0|
    |  Bob|2016-05-01|       25.0|
    |  Bob|2016-05-04|       29.0|
    |  Bob|2016-05-06|       27.0|
    +-----+----------+-----------+



  - //--Import the window functions....
	- scala> 
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._ 
	
	
	
	- //--Create a window spec #1.... => rowsBetween(start: Long, end: Long): WindowSpec
	- scala> val wSpec1 = Window.partitionBy("name").orderBy("date").rowsBetween(-1, 1)
	
	
	
	- //--#01. Calculate the 'moving average'.... => over(window: WindowSpec): Column => Defines a windowing column....
	- scala> customers.withColumn("movingAvg", avg(customers("amountSpent")).over(wSpec1)).show()
    
    +-----+----------+-----------+---------+
    | name|      date|amountSpent|movingAvg|
    +-----+----------+-----------+---------+
    |  Bob|2016-05-01|       25.0|     27.0|
    |  Bob|2016-05-04|       29.0|     27.0|
    |  Bob|2016-05-06|       27.0|     28.0|
    |Alice|2016-05-01|       50.0|     47.5|
    |Alice|2016-05-03|       45.0|     50.0|
    |Alice|2016-05-04|       55.0|     50.0|
    +-----+----------+-----------+---------+
  
  
  
  - //--#02. Calculate the 'total average'.... => over(): Column => Defines an empty analytic clause....
	- scala> customers.withColumn("movingAvg", avg(customers("amountSpent")).over()).show()
		WARN WindowExec: No Partition Defined for Window operation! Moving all data to a single partition, this can cause serious performance degradation.
	
		+-----+----------+-----------+---------+
    | name|      date|amountSpent|movingAvg|
    +-----+----------+-----------+---------+
    |Alice|2016-05-01|       50.0|     38.5|
    |Alice|2016-05-03|       45.0|     38.5|
    |Alice|2016-05-04|       55.0|     38.5|
    |  Bob|2016-05-01|       25.0|     38.5|
    |  Bob|2016-05-04|       29.0|     38.5|
    |  Bob|2016-05-06|       27.0|     38.5|
    +-----+----------+-----------+---------+
	
	
	
	- //--#03. Calculate the 'partition(e.g. per "name") average'.... => over(window: WindowSpec): Column => Defines a windowing column....
	- scala> customers.withColumn("movingAvg", avg(customers("amountSpent")).over(Window.partitionBy("name"))).show()
	
		+-----+----------+-----------+---------+
    | name|      date|amountSpent|movingAvg|
    +-----+----------+-----------+---------+
    |  Bob|2016-05-01|       25.0|     27.0|
    |  Bob|2016-05-04|       29.0|     27.0|
    |  Bob|2016-05-06|       27.0|     27.0|
    |Alice|2016-05-01|       50.0|     50.0|
    |Alice|2016-05-03|       45.0|     50.0|
    |Alice|2016-05-04|       55.0|     50.0|
    +-----+----------+-----------+---------+
	
	
	  
  - //--#04. 'rowsBetween' vs. 'rangeBetween'
  - //--rowsBetween(start: Long, end: Long): WindowSpec => 로우(row)의 위치(position)로 window 범위가 정해지므로.... orderBy 컬럼과 Aggregation(sum 등) 컬럼이 같지 않아도 됨.... => A row based boundary is based on the position of the row within the partition. An offset indicates the number of rows above or below the current row, the frame for the current row starts or ends.
  - //--rangeBetween(start: Long, end: Long): WindowSpec => 컬럼의 값(value)으로 window 범위가 정해지므로.... orderBy 컬럼과 Aggregation(sum, avg etc.) 컬럼이 같아야 함.... => A range-based boundary is based on the 'actual value' of the ORDER BY expression(s). An offset is used to alter the 'value' of the ORDER BY expression, for instance if the current order by expression has a value of 10 and the lower bound offset is -3, the resulting lower bound for the current row will be 10 - 3 = 7.
  - scala> val wSpec2 = Window.partitionBy("name").orderBy("amountSpent")
  
  - scala> 
customers.select(
	$"name", 
	$"date", 
	$"amountSpent", 
	sum("amountSpent").over(wSpec2.rangeBetween(Window.currentRow, 5)).as("range"), 
	avg("amountSpent").over(wSpec2.rowsBetween(Window.currentRow, 1)).as("rows")
).show()
     
    +-----+----------+-----------+-----+----+
    | name|      date|amountSpent|range|rows|
    +-----+----------+-----------+-----+----+
    |  Bob|2016-05-01|       25.0| 81.0|26.0|
    |  Bob|2016-05-06|       27.0| 56.0|28.0|
    |  Bob|2016-05-04|       29.0| 29.0|29.0|
    |Alice|2016-05-03|       45.0| 95.0|47.5|
    |Alice|2016-05-01|       50.0|105.0|52.5|
    |Alice|2016-05-04|       55.0| 55.0|55.0|
    +-----+----------+-----------+-----+----+
	
	
	  
  - //--#05. 'rowsBetween' vs. 'rangeBetween' #2....
  - //--rowsBetween(start: Long, end: Long): WindowSpec => 로우(row)의 위치(position)로 window 범위가 정해지므로.... orderBy 컬럼과 Aggregation(sum 등) 컬럼이 같지 않아도 됨.... => A row based boundary is based on the position of the row within the partition. An offset indicates the number of rows above or below the current row, the frame for the current row starts or ends.
  - //--rangeBetween(start: Long, end: Long): WindowSpec => 컬럼의 값(value)으로 window 범위가 정해지므로.... orderBy 컬럼과 Aggregation(sum, avg etc.) 컬럼이 같아야 함.... => A range-based boundary is based on the 'actual value' of the ORDER BY expression(s). An offset is used to alter the 'value' of the ORDER BY expression, for instance if the current order by expression has a value of 10 and the lower bound offset is -3, the resulting lower bound for the current row will be 10 - 3 = 7.
  - scala> val wSpec2 = Window.partitionBy("name").orderBy("amountSpent")
  
  - scala> 
customers.select(
	$"name", 
	$"date", 
	$"amountSpent", 
	sum("amountSpent").over(wSpec2.rangeBetween(Window.currentRow, 5)).as("range"), 
	avg("amountSpent").over(wSpec2.rowsBetween(Window.currentRow, 1)).as("rows"), 
	avg("amountSpent").over(wSpec1).as("rows2"), 
	sum("amountSpent").over(Window.orderBy($"amountSpent".desc).rangeBetween(Window.currentRow, 5)).as("range2")	//--orderBy DESC.... => rangeBetween MINUS....
).show()
WARN WindowExec: No Partition Defined for Window operation! Moving all data to a single partition, this can cause serious performance degradation.     
    +-----+----------+-----------+-----+----+-----+------+
    | name|      date|amountSpent|range|rows|rows2|range2|
    +-----+----------+-----------+-----+----+-----+------+
    |Alice|2016-05-04|       55.0| 55.0|55.0| 50.0| 105.0|
    |Alice|2016-05-01|       50.0|105.0|52.5| 47.5|  95.0|
    |Alice|2016-05-03|       45.0| 95.0|47.5| 50.0|  45.0|
    |  Bob|2016-05-04|       29.0| 29.0|29.0| 27.0|  81.0|
    |  Bob|2016-05-06|       27.0| 56.0|28.0| 28.0|  52.0|
    |  Bob|2016-05-01|       25.0| 81.0|26.0| 27.0|  25.0|
    +-----+----------+-----------+-----+----+-----+------+


     
 * 
 */
object SparkShell {
  
}