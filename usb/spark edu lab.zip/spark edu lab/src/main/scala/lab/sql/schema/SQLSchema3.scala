package lab.sql.schema

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.sql.types._

object SQLSchema3 {
  
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("SQLSchema3")
      .config("spark.sql.warehouse.dir", "spark-warehouse")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames....
    import spark.implicits._
    
    val eventDayFiles = "src/main/resources/eventday/eventday_*.json"
    
    val eventDayDS = spark
      .read
      .option("wholetext", true)  //--wholetext ( default false): If true, read a file as a single row and not split by "\n"....
//    .option("lineSep", "type")  //--lineSep (default covers all \r, \r\n and \n): defines the line separator that should be used for parsing....      
      .textFile(eventDayFiles)    //--by read.textFile(paths: String*): Dataset[String]
    
    eventDayDS.printSchema()
//  eventDayDS.show(10, 200, true)  //--2.3.0 버전부터 지원.... //--show(numRows: Int, truncate: Int, vertical: Boolean) => vertical : prints output rows vertically (one line per column value).
    
    
    /*
      root
       |-- count: long (nullable = true)
       |-- page: long (nullable = true)
       |-- results: array (nullable = true)
       |    |-- element: struct (containsNull = true)
       |    |    |-- day: string (nullable = true)
       |    |    |-- month: string (nullable = true)
       |    |    |-- name: string (nullable = true)
       |    |    |-- type: string (nullable = true)
       |    |    |-- year: string (nullable = true)
       |-- totalResult: long (nullable = true)
    */
    
    
    val schema = StructType(  //-- new StructType(fields: Array[StructField])
           StructField("count", LongType) 
        :: StructField("page", LongType, true) 
        :: StructField("results", new ArrayType(  //--new ArrayType(elementType: DataType, containsNull: Boolean)
                  StructType(
                       StructField("day", StringType) 
                    :: StructField("month", StringType) 
                    :: StructField("name", StringType) 
                    :: StructField("type", StringType, false).withComment("""기념일 종류 => 법정공휴일(h), 법정기념일(a), 24절기(s), 그외 절기(t), 대중기념일(p), 대체 공휴일(i), 기타(e) => 복수의 타입일 경우 “,” 로 구분해서 나타냄....""") 
                    :: StructField("year", StringType) 
                    :: Nil
                  )
                , true  //--containsNull => Indicates if values have null values....
              )
           ) 
        :: StructField("totalResult", LongType) 
        :: Nil  //--무(無), 영(零)....
    )
    
    
    //--for List Test....
    val listInt = 1 :: 2 :: 3 :: Nil
    val listString = "1" :: "2" :: "3" :: Nil
    val listAny = 1 :: 2L :: "3" :: Nil
    
    
    //--[Case #3]
    val eventDayDF = spark
      .read
      .schema(schema)  //--set schema(StructType).... => skip the schema inference step, and thus speed up data loading....
      .json(eventDayDS)  //--read json from Dataset[JSON String]....
    
    eventDayDF.printSchema()
    eventDayDF.show(5, 40)  //--show(numRows: Int, truncate: Int)  => set truncate characters length....
    eventDayDF.show(5, 40, true)  //--2.3.0 버전부터 지원.... //--show(numRows: Int, truncate: Int, vertical: Boolean) => vertical : prints output rows vertically (one line per column value).
    
    
//  while(true) {Thread.sleep(10000)}  //--for debug....
    spark.stop()
  }   
  
}