package lab.sql.window

/**
 * 
 
 
 1. Spark Shell 연결.... Spark SQL for Window....
  
  - # ./bin/spark-shell --master spark://CentOS7-14:7077
  
  - //--Building the customer DataFrame....
  - scala> 
val customers = sc.
	parallelize(
		List(
			("Alice", "2019-07-12 11:02:31.147", 50.00), 
			("Alice", "2019-07-12 11:02:31.199", 45.00), 
			("Alice", "2019-07-12 11:02:31.214", 55.00), 
			("Bob", "2019-07-12 13:02:31.114", 25.00), 
			("Bob", "2019-07-12 13:02:31.169", 29.00), 
			("Bob", "2019-07-12 13:02:31.198", 27.00)
		)
	).
	toDF("name", "date", "amountSpent")

  - scala> customers.show(false)
  
  	+-----+-----------------------+-----------+
    |name |date                   |amountSpent|
    +-----+-----------------------+-----------+
    |Alice|2019-07-12 11:02:31.147|50.0       |
    |Alice|2019-07-12 11:02:31.199|45.0       |
    |Alice|2019-07-12 11:02:31.214|55.0       |
    |Bob  |2019-07-12 13:02:31.114|25.0       |
    |Bob  |2019-07-12 13:02:31.169|29.0       |
    |Bob  |2019-07-12 13:02:31.198|27.0       |
    +-----+-----------------------+-----------+
  	    
  	  
  	  
  - //--Import the window functions....
	- scala> 
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._



	- //--Add "unix_timestamp" and "timestamp" columns.... #01....
	- scala> 
val customers2 = customers.
	withColumn("unix_timestamp", unix_timestamp('date, "yyyy-MM-dd HH:mm:ss.SSS")).	//--unix_timestamp(s: Column, p: String): Column => Converts time string with given pattern to Unix timestamp (in seconds) as a long.
	withColumn("timestamp", 'unix_timestamp.cast("timestamp"))	//--cast(to: String): Column => Casts the column to a different data type, using the canonical string representation of the type. The supported types are: string, boolean, byte, short, int, long, float, double, decimal, date, timestamp.
  
  - scala> customers2.show(false)
  
  	+-----+-----------------------+-----------+--------------+-------------------+
    |name |date                   |amountSpent|unix_timestamp|timestamp          |
    +-----+-----------------------+-----------+--------------+-------------------+
    |Alice|2019-07-12 11:02:31.147|50.0       |1562896951    |2019-07-12 11:02:31|
    |Alice|2019-07-12 11:02:31.199|45.0       |1562896951    |2019-07-12 11:02:31|
    |Alice|2019-07-12 11:02:31.214|55.0       |1562896951    |2019-07-12 11:02:31|
    |Bob  |2019-07-12 13:02:31.114|25.0       |1562904151    |2019-07-12 13:02:31|
    |Bob  |2019-07-12 13:02:31.169|29.0       |1562904151    |2019-07-12 13:02:31|
    |Bob  |2019-07-12 13:02:31.198|27.0       |1562904151    |2019-07-12 13:02:31|
    +-----+-----------------------+-----------+--------------+-------------------+
      	    
    
    
 	- //--Add "timestamp2" columns.... #02....
	- scala> 
val customers3 = customers2.
	withColumn("timestamp2", to_timestamp('date, "yyyy-MM-dd HH:mm:ss.SSS"))	//--to_timestamp(s: Column, fmt: String): Column => Converts time string with the given pattern to timestamp.
  
  - scala> customers3.show(false)
  
  	+-----+-----------------------+-----------+--------------+-------------------+-------------------+
    |name |date                   |amountSpent|unix_timestamp|timestamp          |timestamp2         |
    +-----+-----------------------+-----------+--------------+-------------------+-------------------+
    |Alice|2019-07-12 11:02:31.147|50.0       |1562896951    |2019-07-12 11:02:31|2019-07-12 11:02:31|
    |Alice|2019-07-12 11:02:31.199|45.0       |1562896951    |2019-07-12 11:02:31|2019-07-12 11:02:31|
    |Alice|2019-07-12 11:02:31.214|55.0       |1562896951    |2019-07-12 11:02:31|2019-07-12 11:02:31|
    |Bob  |2019-07-12 13:02:31.114|25.0       |1562904151    |2019-07-12 13:02:31|2019-07-12 13:02:31|
    |Bob  |2019-07-12 13:02:31.169|29.0       |1562904151    |2019-07-12 13:02:31|2019-07-12 13:02:31|
    |Bob  |2019-07-12 13:02:31.198|27.0       |1562904151    |2019-07-12 13:02:31|2019-07-12 13:02:31|
    +-----+-----------------------+-----------+--------------+-------------------+-------------------+
  	  


  - //--Import SimpleDateFormat....
	- scala> 
import java.text.SimpleDateFormat
import java.sql.Timestamp
  
  
  
  - //--Register "to_timestamp_millisecond" UDF....
	- scala> 
val to_timestamp_millisecond = spark.udf.register("to_timestamp_millisecond", (date: String) => {
	val simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
	new Timestamp(simpleDateFormat.parse(date).getTime)	//--in millisecond....
})



	- //--Add "timestamp3" columns.... #03....
	- scala> 
val customers4 = customers3.
	withColumn("timestamp3", to_timestamp_millisecond('date))	//--use UDF "to_timestamp_millisecond"....
  
  - scala> customers4.show(false)
  
  	+-----+-----------------------+-----------+--------------+-------------------+-------------------+-----------------------+
    |name |date                   |amountSpent|unix_timestamp|timestamp          |timestamp2         |timestamp3             |
    +-----+-----------------------+-----------+--------------+-------------------+-------------------+-----------------------+
    |Alice|2019-07-12 11:02:31.147|50.0       |1562896951    |2019-07-12 11:02:31|2019-07-12 11:02:31|2019-07-12 11:02:31.147|
    |Alice|2019-07-12 11:02:31.199|45.0       |1562896951    |2019-07-12 11:02:31|2019-07-12 11:02:31|2019-07-12 11:02:31.199|
    |Alice|2019-07-12 11:02:31.214|55.0       |1562896951    |2019-07-12 11:02:31|2019-07-12 11:02:31|2019-07-12 11:02:31.214|
    |Bob  |2019-07-12 13:02:31.114|25.0       |1562904151    |2019-07-12 13:02:31|2019-07-12 13:02:31|2019-07-12 13:02:31.114|
    |Bob  |2019-07-12 13:02:31.169|29.0       |1562904151    |2019-07-12 13:02:31|2019-07-12 13:02:31|2019-07-12 13:02:31.169|
    |Bob  |2019-07-12 13:02:31.198|27.0       |1562904151    |2019-07-12 13:02:31|2019-07-12 13:02:31|2019-07-12 13:02:31.198|
    +-----+-----------------------+-----------+--------------+-------------------+-------------------+-----------------------+
    	    
  - scala> customers4.printSchema
  
  	root
     |-- name: string (nullable = true)
     |-- date: string (nullable = true)
     |-- amountSpent: double (nullable = false)
     |-- unix_timestamp: long (nullable = true)
     |-- timestamp: timestamp (nullable = true)
     |-- timestamp2: timestamp (nullable = true)
     |-- timestamp3: timestamp (nullable = true)
  	    
    
     
	- //--#01. window(timeColumn: Column, windowDuration: String): Column
	- scala> 
customers4.
	groupBy($"name", window($"timestamp3", "50 milliseconds")).
 	agg(mean("amountSpent"), sum("amountSpent")).
 	orderBy('name, 'window).
 	show(false)
 	
 		+-----+-----------------------------------------------+----------------+----------------+
    |name |window                                         |avg(amountSpent)|sum(amountSpent)|
    +-----+-----------------------------------------------+----------------+----------------+
    |Alice|[2019-07-12 11:02:31.1, 2019-07-12 11:02:31.15]|50.0            |50.0            |
    |Alice|[2019-07-12 11:02:31.15, 2019-07-12 11:02:31.2]|45.0            |45.0            |
    |Alice|[2019-07-12 11:02:31.2, 2019-07-12 11:02:31.25]|55.0            |55.0            |
    |Bob  |[2019-07-12 13:02:31.1, 2019-07-12 13:02:31.15]|25.0            |25.0            |
    |Bob  |[2019-07-12 13:02:31.15, 2019-07-12 13:02:31.2]|28.0            |56.0            |
    +-----+-----------------------------------------------+----------------+----------------+
     		
     	
		
	- //--#02. window(timeColumn: Column, windowDuration: String, slideDuration: String): Column
	- scala> 
customers4.
	groupBy($"name", window($"timestamp3", "50 milliseconds", "30 milliseconds")).
 	agg(avg("amountSpent").as("avg_amountSpent"), sum("amountSpent").as("sum_amountSpent")).
 	orderBy('name, 'window).
 	withColumn("start", $"window.start").
 	withColumn("end", $"window.end").
 	show(false)

 		+-----+------------------------------------------------+---------------+---------------+----------------------+----------------------+
    |name |window                                          |avg_amountSpent|sum_amountSpent|start                 |end                   |
    +-----+------------------------------------------------+---------------+---------------+----------------------+----------------------+
    |Alice|[2019-07-12 11:02:31.11, 2019-07-12 11:02:31.16]|50.0           |50.0           |2019-07-12 11:02:31.11|2019-07-12 11:02:31.16|
    |Alice|[2019-07-12 11:02:31.14, 2019-07-12 11:02:31.19]|50.0           |50.0           |2019-07-12 11:02:31.14|2019-07-12 11:02:31.19|
    |Alice|[2019-07-12 11:02:31.17, 2019-07-12 11:02:31.22]|50.0           |100.0          |2019-07-12 11:02:31.17|2019-07-12 11:02:31.22|
    |Alice|[2019-07-12 11:02:31.2, 2019-07-12 11:02:31.25] |55.0           |55.0           |2019-07-12 11:02:31.2 |2019-07-12 11:02:31.25|
    |Bob  |[2019-07-12 13:02:31.08, 2019-07-12 13:02:31.13]|25.0           |25.0           |2019-07-12 13:02:31.08|2019-07-12 13:02:31.13|
    |Bob  |[2019-07-12 13:02:31.11, 2019-07-12 13:02:31.16]|25.0           |25.0           |2019-07-12 13:02:31.11|2019-07-12 13:02:31.16|
    |Bob  |[2019-07-12 13:02:31.14, 2019-07-12 13:02:31.19]|29.0           |29.0           |2019-07-12 13:02:31.14|2019-07-12 13:02:31.19|
    |Bob  |[2019-07-12 13:02:31.17, 2019-07-12 13:02:31.22]|27.0           |27.0           |2019-07-12 13:02:31.17|2019-07-12 13:02:31.22|
    +-----+------------------------------------------------+---------------+---------------+----------------------+----------------------+
        	
	- scala> //-- cf) groupBy($"name", window($"timestamp3", "50 milliseconds")).
customers4.
	groupBy($"name", window($"timestamp3", "50 milliseconds", "50 milliseconds")).
 	agg(mean("amountSpent"), sum("amountSpent")).
 	orderBy('name, 'window).
 	show(false)

 		+-----+-----------------------------------------------+----------------+----------------+
    |name |window                                         |avg(amountSpent)|sum(amountSpent)|
    +-----+-----------------------------------------------+----------------+----------------+
    |Alice|[2019-07-12 11:02:31.1, 2019-07-12 11:02:31.15]|50.0            |50.0            |
    |Alice|[2019-07-12 11:02:31.15, 2019-07-12 11:02:31.2]|45.0            |45.0            |
    |Alice|[2019-07-12 11:02:31.2, 2019-07-12 11:02:31.25]|55.0            |55.0            |
    |Bob  |[2019-07-12 13:02:31.1, 2019-07-12 13:02:31.15]|25.0            |25.0            |
    |Bob  |[2019-07-12 13:02:31.15, 2019-07-12 13:02:31.2]|28.0            |56.0            |
    +-----+-----------------------------------------------+----------------+----------------+
     		   		

		
	- //--#03. window(timeColumn: Column, windowDuration: String, slideDuration: String, startTime: String): Column
	- scala> 
customers4.
	groupBy($"name", window($"timestamp3", "50 milliseconds", "30 milliseconds", "-5 milliseconds")).
 	agg(mean("amountSpent"), sum("amountSpent")).
 	orderBy('name, 'window).
 	show(false)

 		+-----+--------------------------------------------------+----------------+----------------+
    |name |window                                            |avg(amountSpent)|sum(amountSpent)|
    +-----+--------------------------------------------------+----------------+----------------+
    |Alice|[2019-07-12 11:02:31.105, 2019-07-12 11:02:31.155]|50.0            |50.0            |
    |Alice|[2019-07-12 11:02:31.135, 2019-07-12 11:02:31.185]|50.0            |50.0            |
    |Alice|[2019-07-12 11:02:31.165, 2019-07-12 11:02:31.215]|50.0            |100.0           |
    |Alice|[2019-07-12 11:02:31.195, 2019-07-12 11:02:31.245]|50.0            |100.0           |
    |Bob  |[2019-07-12 13:02:31.075, 2019-07-12 13:02:31.125]|25.0            |25.0            |
    |Bob  |[2019-07-12 13:02:31.105, 2019-07-12 13:02:31.155]|25.0            |25.0            |
    |Bob  |[2019-07-12 13:02:31.135, 2019-07-12 13:02:31.185]|29.0            |29.0            |
    |Bob  |[2019-07-12 13:02:31.165, 2019-07-12 13:02:31.215]|28.0            |56.0            |
    |Bob  |[2019-07-12 13:02:31.195, 2019-07-12 13:02:31.245]|27.0            |27.0            |
    +-----+--------------------------------------------------+----------------+----------------+
     		     		
	- scala> //-- cf) groupBy($"name", window($"timestamp3", "50 milliseconds")).
customers4.
	groupBy($"name", window($"timestamp3", "50 milliseconds", "50 milliseconds", "-10 milliseconds")).
 	agg(mean("amountSpent"), sum("amountSpent")).
 	orderBy('name, 'window).
 	show(false)

 		+-----+------------------------------------------------+----------------+----------------+
    |name |window                                          |avg(amountSpent)|sum(amountSpent)|
    +-----+------------------------------------------------+----------------+----------------+
    |Alice|[2019-07-12 11:02:31.14, 2019-07-12 11:02:31.19]|50.0            |50.0            |
    |Alice|[2019-07-12 11:02:31.19, 2019-07-12 11:02:31.24]|50.0            |100.0           |
    |Bob  |[2019-07-12 13:02:31.09, 2019-07-12 13:02:31.14]|25.0            |25.0            |
    |Bob  |[2019-07-12 13:02:31.14, 2019-07-12 13:02:31.19]|29.0            |29.0            |
    |Bob  |[2019-07-12 13:02:31.19, 2019-07-12 13:02:31.24]|27.0            |27.0            |
    +-----+------------------------------------------------+----------------+----------------+



 * 
 */
object SparkShell3 {
  
}