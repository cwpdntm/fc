package lab.sql.schema

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object SQLSchema4 {
  
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("SQLSchema4")
      .config("spark.sql.warehouse.dir", "spark-warehouse")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames....
    import spark.implicits._
    
    val eventDayFiles = "src/main/resources/eventday/eventday_*.json"
    
    val eventDayDS = spark
      .read
      .option("wholetext", true)  //--wholetext ( default false): If true, read a file as a single row and not split by "\n"....
      .textFile(eventDayFiles)    //--by read.textFile(paths: String*): Dataset[String]
      
    eventDayDS.printSchema()
//  eventDayDS.show(10, 200, true)  //--2.3.0 버전부터 지원.... //--show(numRows: Int, truncate: Int, vertical: Boolean) => vertical : prints output rows vertically (one line per column value).
    
    
    /*
      root
       |-- count: long (nullable = true)
       |-- page: long (nullable = true)
       |-- results: array (nullable = true)
       |    |-- element: struct (containsNull = true)
       |    |    |-- day: string (nullable = true)
       |    |    |-- month: string (nullable = true)
       |    |    |-- name: string (nullable = true)
       |    |    |-- type: string (nullable = true)
       |    |    |-- year: string (nullable = true)
       |-- totalResult: long (nullable = true)
    */
    
    
    //--Small JSON reading....
    /*
    val schemaDS = spark
    	.sparkContext
      .parallelize(Array("""{"totalResult":0,"page":0,"count":0,"results":[{"year":"2017","month":"08","day":"10","type":"h","name":"테스트"}]}"""))
      .toDS  //--RDD[String] to Dataset[String]....
    */
    val schemaDS = Array("""
        {
          "totalResult":0,
          "page":0,
          "count":0,
          "results":[
            {
              "year":"2017",
              "month":"08",
              "day":"10",
              "type":"h",
              "name":"테스트"
            }
          ]
        }
      """)
      .toSeq  //--toSeq....
//    .toDF()
      .toDS  //--Seq[String] to Dataset[String]....
      
    val schemaDF = spark
      .read
      .json(schemaDS)  //--read json from Dataset[JSON String]....
    
      
    //--[Case #4]
    val eventDayDF = spark
      .read
      .schema(schemaDF.schema)  //--set schema(DataFrame.schema).... => skip the schema inference step, and thus speed up data loading....
      .json(eventDayDS)  //--read json from Dataset[JSON String]....
    
    eventDayDF.printSchema()
    eventDayDF.show(false)
    
    
//  while(true) {Thread.sleep(10000)}  //--for debug....
    spark.stop()
  }   
  
}