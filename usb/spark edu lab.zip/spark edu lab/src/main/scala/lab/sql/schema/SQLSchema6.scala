package lab.sql.schema

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object SQLSchema6 {
  
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("SQLSchema4")
      .config("spark.sql.warehouse.dir", "spark-warehouse")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames....
    import spark.implicits._
    
    val eventDayFiles = "src/main/resources/eventday/eventday_*.json"
        
    
    /*
      root
       |-- count: long (nullable = true)
       |-- page: long (nullable = true)
       |-- results: array (nullable = true)
       |    |-- element: struct (containsNull = true)
       |    |    |-- day: string (nullable = true)
       |    |    |-- month: string (nullable = true)
       |    |    |-- name: string (nullable = true)
       |    |    |-- type: string (nullable = true)
       |    |    |-- year: string (nullable = true)
       |-- totalResult: long (nullable = true)
    */
    
    
    val schemaEncoder = org.apache.spark.sql.Encoders.product[EventDays]  //--Since 2.0.0.... Encoders.product[T]: Encoder[T] => An encoder for Scala's product type (tuples, case classes, etc)....
    
    
    //--[Case #6]
    val eventDayDF = spark
      .read
      .schema(schemaEncoder.schema)
      .option("multiLine", true)  //--set multiLine true.... => multiLine (default false): parse one record, which may span multiple lines, per file....
      .json(eventDayFiles)        //-json(paths: String*): DataFrame
    
    eventDayDF.printSchema()
    eventDayDF.show(false)
    
    
    
    
    //--posexplode() 함수 in DF.API().... Creates a new row for each element 'with position' in the given array or map column....
    val eventDayDF2 = eventDayDF.select('count, 'page, posexplode('results).as(Array("index", "result")), 'totalResult)
    eventDayDF2.printSchema()
    eventDayDF2.show(400, 50)
    
    
    //--explode() 함수 in DF.API().... Creates a new row for each element in the given array or map column....
    val eventDayDF2_1 = eventDayDF.select('count, 'page, explode('results).as("result"), 'totalResult)
    eventDayDF2_1.printSchema()
    eventDayDF2_1.show(11)
    
    
    val eventDayDF3 = eventDayDF2.select('count, 'page, $"result.day", $"result.month", $"result.name", $"result.type", $"result.year", 'totalResult)
    eventDayDF3.printSchema()
    eventDayDF3.show(false)
    
    
    
    //--explode() 함수 in SQL문.... Creates a new row for each element in the given array or map column.... ds.select(explode(split('words, " ")).as("word"))
    eventDayDF.createOrReplaceTempView("eventDay")
    val eventDayDF4 = spark.sql("SELECT count, page, explode(results) as result, totalResult FROM eventDay")
    eventDayDF4.printSchema()
    eventDayDF4.show(15, false)
    
    eventDayDF4.createOrReplaceTempView("eventDay2")
    val eventDayDF5 = spark.sql("SELECT count, page, result.day, result.month, result.name, result.type, result.year, totalResult FROM eventDay2")
    eventDayDF5.printSchema()
    eventDayDF5.show(false)
    
    
//  while(true) {Thread.sleep(10000)}  //--for debug....
    spark.stop()
  }   
  
  case class EventDays(count: Long, page: Long, results: Seq[EventDay], totalResult: Long){}
  case class EventDay(day: String, month: String, name: String, `type`: String, year: String){}  //--스칼라에서는 백틱(`)을 통해 예약어 사용.... ex) myVarialbe.`class`

}