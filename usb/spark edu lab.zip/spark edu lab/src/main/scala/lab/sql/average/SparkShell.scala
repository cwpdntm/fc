package lab.sql.average

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}

/**
 * 
 
 
 1. Spark Shell 연결.... Spark SQL for Window....
  
  - # ./bin/spark-shell --master spark://CentOS7-14:7077
  
  - //--정형 데이터(JSON)....
  - scala> val people = spark.read.json("examples/src/main/resources/people.json")
  - scala> people.createOrReplaceTempView("people")
  - scala> spark.sql("SELECT name, avg(age) FROM people GROUP BY name").show
 * 
 */
object SparkShell {
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    //--비정형 데이터(TEXT)....
    val peopleFile = "src/main/resources/people.info"
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("AverageSQL")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames
    import spark.implicits._
    
    val people = spark
      .sparkContext  //--SparkContext....
      .textFile(peopleFile)  //--RDD[String]....
      .map { x => x.split("\t") }  //--이름(name)과 나이(age) 탭("\t")으로 구분.... Array[name, age]
      .map { x => (x(0), x(1)) }   //--(name, age) 튜플 생성....                             
//    .toDF()  //--columns: [_1, _2]....
//    .toDS()
      .toDF("name", "age")    //--컬럼명 지정....
      
    people.createOrReplaceTempView("people")
    spark
      .table("people")
      .printSchema()
    
    spark
      .sql("SELECT name, avg(age) as avg_age FROM people GROUP BY name")
      .toDF("name2", "avg_age2")  //--컬럼명 변경....
      .show
    
      
    while(true) {Thread.sleep(10000)}  //--for debug....
    
    /*
     * Web UI (http://localhost:4042/) 확인.... Average vs. SparkShell....
     * - Job 개수.... (vs. Average) => 5개.... (vs. Average는 1개) => why 5개????
     * - Stage 개수.... (vs. Average) 
     * - Task 개수.... (vs. Average) => 3개(2개 + 1개) + 4개 + 20개 + 100개 + 75개 => 2개(첫번째 Stage) + 200개(두번째 Stage) => 200개???? (Default: 200.... Configures the number of partitions to use when shuffling data for joins or aggregations....) => Why 하나의 Stage에서 200개 Task를 처리하지 않고 다수의 Job으로 나누어서 처리할까? => 할당된 Core 개수(2개)가 적어서???? 
     * - Shuffle File 사이즈.... (vs. Average) => 후속 Stage의 Shuffle Read가 없는, 놀고 있는 Stage 존재????
     */
                             
    spark.stop()
  }
}