package lab.sql.jdbc.mysql

/**
 * 
 1. MySQL 설치 on CentOS7....
  - # yum install -y http://dev.mysql.com/get/mysql-community-release-el7-5.noarch.rpm
  - # yum install -y mysql-community-server
  - # systemctl start mysqld
  - # systemctl status mysqld.service
  - # systemctl enable mysqld
 
 
 
 
 2. 원격접속 허용(root계정 모든 IP 허용).... + Table 생성 및 Data 추가....
  - # cd /usr/bin //--불필요....
  - # mysql
  - mysql> SELECT Host,User,Password FROM mysql.user;
  - mysql> INSERT INTO mysql.user (host, user, password, ssl_cipher, x509_issuer, x509_subject) VALUES ('%','root',password(''),'','','');
  - mysql> GRANT ALL PRIVILEGES ON *.* TO 'root'@'%';
  - mysql> FLUSH PRIVILEGES;
  - mysql> show databases;
  - mysql> use mysql;
  - mysql> DROP TABLE IF EXISTS projects;
  - mysql> 
CREATE TABLE projects (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255),
  website varchar(255),
  manager varchar(255),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
  - mysql> describe projects;
  - mysql> 
INSERT INTO projects (name, website, manager) VALUES ('Apache Spark', 'http://spark.apache.org', 'Michael');
INSERT INTO projects (name, website, manager) VALUES ('Apache Hive', 'http://hive.apache.org', 'Andy');
INSERT INTO projects VALUES (DEFAULT, 'Apache Kafka', 'http://kafka.apache.org', 'Justin');
INSERT INTO projects VALUES (DEFAULT, 'Apache Flink', 'http://flink.apache.org', 'Michael');
  - mysql> SELECT * FROM projects;




 3. MySQL JDBC Driver download.... + upload....
  - https://dev.mysql.com/downloads/connector/j/
  - Platform Independent (Architecture Independent), ZIP Archive > Download > No thanks, just start my download.
  - unzip mysql-connector-java-5.1.39.zip
  - upload mysql-connector-java-5.1.39-bin.jar to CentOS7-14:/kikang/spark-2.4.3-bin-hadoop2.7
 
 
 
 
 4. Spark Shell 연결....
  - # ./bin/spark-shell --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077	 //=> executor 1개 구동....
  - # ./bin/spark-shell --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077 --executor-memory 900m --executor-cores 1 --total-executor-cores 2 --name kikang_spark_shell4 //=> executor 2개 구동.... + executor 별 memory, core 지정.... + App Name 지정....
  - scala> 
val df = spark.
	read.
	format("jdbc").
	option("url", "jdbc:mysql://CentOS7-14:3306/mysql").
	option("driver", "com.mysql.jdbc.Driver").
	option("dbtable", "projects").
	option("user", "root").
	option("password", "").
	load()	//=> <spark_home>/work/<app_home>/<executor_id> 경로내 JDBC 드라이버 jar 파일 존재여부 확인....아직 executor에서는 JDBC 드라이버 jar 파일이 필요없음....
  - scala> df.printSchema	//=> "jdbc" 포맷으로 읽어온 DataFrame의 스키마정보는 Spark Driver에서 읽어온 것임....
  - scala> df.show(false)	//=> <spark_home>/work/<app_home>/<executor_id> 경로내 JDBC 드라이버 jar 파일 존재여부 확인.... 실제 구동(Action 실행)될 때 필요한 jar 파일 가져옴.... 각(?) executor에서 DB로부터 데이터를 읽어오기 위해 JDBC 드라이버 jar 파일을 Spark Driver로부터 가져옴.... => <spark_home>/work/<app_home> 경로에서 "ls -alR" 명령어로 JDBC 드라이버 jar 파일 확인.... 
  - scala> spark.read. + Tab키
  - scala> df.write. + Tab키
  
  
  
  
 5. Persist.... + Table 신규 데이터 입력.... + UnPersist....
  - scala> df.persist
  - scala> df.show(false)
  - mysql> INSERT INTO projects (name, website, manager) VALUES ('Apache Storm', 'http://storm.apache.org', 'Andy');
  - mysql> SELECT * FROM projects;
  - scala> df.show
  - scala> df.unpersist
  - scala> df.show
 
 
 
 
 6. TempView 생성.... + SQL 쿼리....
  - scala> df.createOrReplaceTempView("projects")
  - scala> val sqldf = spark.sql("SELECT * FROM projects WHERE id > 3")
  - scala> sqldf.show
  - scala> spark.table("projects").show(false)
 
 
 
 
 7. Read MySQL Table by SubQuery with Alias.... 
  - scala> 
val subdf = spark.
	read.
	format("jdbc").
	option("url", "jdbc:mysql://CentOS7-14:3306/mysql").
	option("driver", "com.mysql.jdbc.Driver").
	option("dbtable", "(SELECT * FROM projects WHERE id > 3) as subprojects").
	option("user", "root").
	option("password", "").
	load()
  - scala> subdf.show
 
 
 
 
 8. Write MySQL Table.... 
  - scala> df.show  
  - scala> 
val prop: java.util.Properties = new java.util.Properties()
prop.setProperty("user", "root")
prop.setProperty("password", "")
prop.setProperty("driver", "com.mysql.jdbc.Driver")
  
  
  - //--Properties 사용하여 read....
  - scala> 
val df = spark.
	read.
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects", prop) 
  - scala> df.show(false)
  
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert....
  - scala> 
subdf.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Append).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects", prop) 
  - mysql> SELECT * FROM projects;
  
  
  - //--SaveMode.Append => 기존 테이블에 Data Insert.... (Properties 사용하지 않고 option 설정으로 write....)
  - scala> 
subdf.
	select("name", "website", "manager").
	write.
	format("jdbc").
	option("url", "jdbc:mysql://CentOS7-14:3306/mysql").
	option("driver", "com.mysql.jdbc.Driver").
	option("dbtable", "projects").
	option("user", "root").
	option("password", "").
	mode(org.apache.spark.sql.SaveMode.Append).
	save()
  - mysql> SELECT * FROM projects;
  
  
  - //--SaveMode.Overwrite => 신규 테이블 생성("name", "website", "manager") + Data Insert....
  - scala> 
subdf.
	select("name", "website", "manager").
	write.
	mode(org.apache.spark.sql.SaveMode.Overwrite).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_new", prop) 
  - mysql> SELECT * FROM projects_new;
  
  
  - //--SaveMode.Overwrite => 신규 테이블 생성("id", "name", "website", "manager") + Data Insert....
  - scala> 
subdf.
	select("id", "name", "website", "manager").
	write.mode(org.apache.spark.sql.SaveMode.Overwrite).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_new", prop) 
  - mysql> SELECT * FROM projects_new;
  
  
  - //--SaveMode.Overwrite => 신규 테이블 생성("id", "name", "website", "manager", "new_id") + Data Insert....
  - scala> 
subdf.
	select("id", "name", "website", "manager").
	withColumn("new_id", col("id") + 100).
	write.
	mode(org.apache.spark.sql.SaveMode.Overwrite).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_new", prop) 
  - mysql> SELECT * FROM projects_new;
  
  
  - //--SaveMode.Overwrite => 신규 테이블 생성("id", "name", "website", "manager", "website_suffix") with UDFs + Data Insert....
  - scala> 
val extractSuffixUDF = spark.
	udf.
	register("myUDF", (arg1: String) => arg1.substring(arg1.lastIndexOf(".")+1))
  - scala> 
subdf.
	select("id", "name", "website", "manager").
	withColumn("website_suffix", extractSuffixUDF(col("website"))).
	write.
	mode(org.apache.spark.sql.SaveMode.Overwrite).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_new", prop) 
  - scala> 
subdf.
	select("id", "name", "website", "manager").
	withColumn("website_suffix", callUDF("myUDF", 'website)).
	write.
	mode("append").
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_new", prop) 
  - mysql> SELECT * FROM projects_new;
  
  
  - //--SQL 쿼리 기반....SaveMode.Overwrite => 신규 테이블 생성("id", "name", "website", "manager", "website_suffix_by_sql") with UDFs + Data Insert....
  - scala> 
spark.
	sql("""
		SELECT id, name, website, manager, myUDF(website) as website_suffix_by_sql 
		FROM projects
	""").
	write.
	mode(org.apache.spark.sql.SaveMode.Overwrite).
	jdbc("jdbc:mysql://CentOS7-14:3306/mysql", "projects_new", prop) 
  - mysql> SELECT * FROM projects_new;
  
  
  
  
 9. JOIN.... => json JOIN jdbc.... BroadcastJoin.... Predicate Pushdown....
  - //--Dataset JOIN....
  - scala> 
val people = spark.
	read.
	json("examples/src/main/resources/people.json")
  - scala> people.show
  - scala> people.schema
  - scala> people.printSchema
  - scala> df.show
  - scala> people.filter("age > 11").show
  - scala> people.where("age > 11").show
  
  
  - //--BroadcastHashJoin.... => Driver UI > SQL > Description Link > Query DAG....
  - scala> 
people.
	filter("age > 11").
	join(df, people("name") === df("manager")).
	show
  
  
  - //--BroadcastHashJoin + Predicate Pushdown.... => Driver UI > SQL > Description Link > Query DAG....
  - scala> 
people.
	join(df, people("name") === df("manager")).
	filter("age > 11").
	show	
  
  
  - //--multiple aggregations....
  - scala> 
people.
	filter("age > 11").
	join(df, people("name") === df("manager")).
	groupBy(df("website")).
	count.
	show
  - scala> 
people.
	filter("age > 11").
	join(df, people("name") === df("manager")).
	groupBy(df("website")).
	agg(avg(people("age")), max(df("id"))).
	show
  
  
  - //--SQL JOIN....
  - scala> people.createOrReplaceTempView("people")
  - scala> 
spark.
	sql("""
		SELECT website, avg(age), max(id) 
		FROM people a 
		JOIN projects b 
		ON a.name = b.manager 
		WHERE a.age > 11 
		GROUP BY b.website
	""").
	show
  
  
  
  
 10. saveAsTable, append mode, insertInto....
  - //--Save on spark-warehouse.... by "saveAsTable()"....
  - scala> 
spark.
	sql("""
		SELECT website, avg(age) avg_age, max(id) max_id 
		FROM people a 
		JOIN projects b 
		ON a.name = b.manager 
		WHERE a.age > 11 
		GROUP BY b.website
	""").
	write.
	mode("overwrite").
	saveAsTable("JoinedPeople")	
  - scala> 
sql("""
		SELECT * 
		FROM JoinedPeople
	""").
	show
  
  
  - //--Unlike insertInto, "saveAsTable" will use the "column names" to find the correct column positions....
  - scala> 
sql("""
		SELECT max_id, avg_age, website 
		FROM JoinedPeople
	""").
	write.
	mode("append").
	saveAsTable("JoinedPeople")	
  - scala> 
sql("""
		SELECT * 
		FROM JoinedPeople
	""").
	show
  
  
  - //--Unlike saveAsTable, "insertInto" ignores the column names and just uses "position-based" resolution....
  - scala> 
sql("""
		SELECT website as site, avg_age as age, max_id as id 
		FROM JoinedPeople
	""").
	write.
	insertInto("JoinedPeople")	
  - scala> 
sql("""
		SELECT * 
		FROM JoinedPeople
	""").
	show
  
  
  - //--예외 발생.... "append" mode => 컬럼명 같아야 함....
  - scala> 
sql("""
		SELECT website as site, avg_age as age, max_id as id 
		FROM JoinedPeople
	""").
	write.
	mode("append").
	saveAsTable("JoinedPeople")	
  
  
  - //--"insertInto" => 컬럼 순서대로 저장.... => 컬럼 타입에 따라 형변환이 안될 경우 "null" 입력됨....
  - scala> 
sql("""
		SELECT max_id, avg_age, website 
		FROM JoinedPeople
	""").
	write.
	insertInto("JoinedPeople")	
  - scala> 
sql("""
		SELECT * 
		FROM JoinedPeople
	""").
	show(100, false)
  - scala> spark.table("JoinedPeople").printSchema
  
  
  - //--Warehouse directory....
  - # cd /kikang/spark-2.4.3-bin-hadoop2.7/spark-warehouse	
  - # ls -al
   
   
   
  
 11. partitionBy.... write, read, read + filter....
 	- //--write.... by partition....
  - scala> df.show(false)
  - scala> 
df.
	write.
	partitionBy("manager", "name").
	mode("overwrite").
	saveAsTable("PartitionTable")
  - scala> 
sql("""
		select * 
		from PartitionTable
	""").
	show(false)	
  
  
  - //--Warehouse directory....
  - # cd /kikang/spark-2.4.3-bin-hadoop2.7/spark-warehouse	
  - # ls -al
    
    
  - //--read.... CatalogFileIndex, file:/테이블 경로까지.... 전체 파티션 읽기.... (PartitionCount: 5, PartitionFilters: []) => Driver UI > SQL > Description Link > Details > Physical Plan....
  - scala> 
spark.
	read.
	table("PartitionTable").
	show(false)	
  
  
  - //--read.... PrunedInMemoryFileIndex, file:/테이블/파티션 경로까지.... 조건("manager = 'Michael'")에 해당하는 파티션만 읽기.... (PartitionCount: 2, PartitionFilters: [isnotnull(manager#889), (manager#889 = Michael)]) => Driver UI > SQL > Description Link > Details > Physical Plan....
  - scala> 
spark.
	read.
	table("PartitionTable").
	filter("manager = 'Michael'").
	show(false)	
  
  
  - //--read.... PrunedInMemoryFileIndex, file:/테이블/파티션 경로까지.... 조건("name = 'Apache Spark'")에 해당하는 파티션만 읽기.... (PartitionCount: 1, PartitionFilters: [isnotnull(name#890), (name#890 = Apache Spark)]) => Driver UI > SQL > Description Link > Details > Physical Plan....
  - scala> 
spark.
	read.
	table("PartitionTable").
	filter("name = 'Apache Spark'").
	show(false)	
  - scala> 
spark.
	read.
	table("PartitionTable").
	filter("name = 'Apache Spark'").
	explain(true)
  
  
  
 * 
 */
object SparkShell {
  
}