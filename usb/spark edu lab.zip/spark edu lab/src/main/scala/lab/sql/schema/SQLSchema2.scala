package lab.sql.schema

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.sql.types._

object SQLSchema2 {
  
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("SQLSchema2")
      .config("spark.sql.warehouse.dir", "spark-warehouse")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames....
    import spark.implicits._
    
    val eventDayFiles = "src/main/resources/eventday/eventday_*.json"
    
    val eventDayValueDF = spark
      .read
      .option("wholetext", true)  //--wholetext ( default false): If true, read a file as a single row and not split by "\n"....
//    .option("lineSep", "type")  //--lineSep (default covers all \r, \r\n and \n): defines the line separator that should be used for parsing....
      .text(eventDayFiles)        //--by read.text(paths: String*): DataFrame
    
    val eventDayDS = eventDayValueDF.as[String]  //--DataFrame.as[String] to Dataset[String]....
    
    eventDayDS.printSchema()
//  eventDayDS.show(10, 200, true)  //--2.3.0 버전부터 지원.... //--show(numRows: Int, truncate: Int, vertical: Boolean) => vertical : prints output rows vertically (one line per column value).
    
    
    /*
      root
       |-- count: long (nullable = true)
       |-- page: long (nullable = true)
       |-- results: array (nullable = true)
       |    |-- element: struct (containsNull = true)
       |    |    |-- day: string (nullable = true)
       |    |    |-- month: string (nullable = true)
       |    |    |-- name: string (nullable = true)
       |    |    |-- type: string (nullable = true)
       |    |    |-- year: string (nullable = true)
       |-- totalResult: long (nullable = true)
    */
    
    
    val schema = (new StructType)
      .add("count", LongType)       //--add(name: String, dataType: String)
      .add("page", LongType, true)  //--add(name: String, dataType: String, nullable: Boolean)
      .add("results", new ArrayType(
              (new StructType)
                .add("day", StringType)
                .add("month", StringType)
                .add("name", StringType)
                .add("type", StringType, false, """기념일 종류 => 법정공휴일(h), 법정기념일(a), 24절기(s), 그외 절기(t), 대중기념일(p), 대체 공휴일(i), 기타(e) => 복수의 타입일 경우 “,” 로 구분해서 나타냄....""")  //--add(name: String, dataType: String, nullable: Boolean, comment: String)
                .add("year", StringType)
            , true  //--containsNull => Indicates if values have null values....
          )
       )
      .add("totalResult", LongType)
    
    
    //--[Case #2] => schema 적용 vs. 미적용 => .schema(schema) 주석처리.... => Web UI에서 Job 개수 비교 확인....
    val eventDayDF = spark
      .read
      .schema(schema)    //--set schema(StructType).... => skip the schema inference step, and thus speed up data loading....
      .json(eventDayDS)  //--read json from Dataset[JSON String]....
    
    eventDayDF.printSchema()
    println(eventDayDF.schema)
    eventDayDF.show(5, 40)  //--show(numRows: Int, truncate: Int)  => set truncate characters length....
    
    
    while(true) {Thread.sleep(10000)}  //--for debug....
    spark.stop()
  }   
  
}