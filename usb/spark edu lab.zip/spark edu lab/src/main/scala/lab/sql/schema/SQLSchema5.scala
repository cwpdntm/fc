package lab.sql.schema

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object SQLSchema5 {
  
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("SQLSchema4")
      .config("spark.sql.warehouse.dir", "spark-warehouse")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames....
    import spark.implicits._
    
    val eventDayFiles = "src/main/resources/eventday/eventday_*.json"
    
    val eventDayDS = spark
      .read
      .option("wholetext", true)  //--wholetext ( default false): If true, read a file as a single row and not split by "\n"....
      .textFile(eventDayFiles)    //--by read.textFile(paths: String*): Dataset[String]
    
    eventDayDS.printSchema()
//  eventDayDS.show(10, 200, true)  //--2.3.0 버전부터 지원.... //--show(numRows: Int, truncate: Int, vertical: Boolean) => vertical : prints output rows vertically (one line per column value).
    
    
    /*
      root
       |-- count: long (nullable = true)
       |-- page: long (nullable = true)
       |-- results: array (nullable = true)
       |    |-- element: struct (containsNull = true)
       |    |    |-- day: string (nullable = true)
       |    |    |-- month: string (nullable = true)
       |    |    |-- name: string (nullable = true)
       |    |    |-- type: string (nullable = true)
       |    |    |-- year: string (nullable = true)
       |-- totalResult: long (nullable = true)
    */
    
    
    val schemaEncoder = org.apache.spark.sql.Encoders.product[EventDays]  //--Since 2.0.0.... Encoders.product[T]: Encoder[T] => An encoder for Scala's product type (tuples, case classes, etc)....
    
    val schema = schemaEncoder.schema
    
    val results = schema("results")
    println(results)
    
    
    //--[Case #5]
    val eventDayDF = spark
      .read
      .schema(schemaEncoder.schema)
      .json(eventDayDS)  //--read json from Dataset[JSON String]....
    
    eventDayDF.printSchema()
    eventDayDF.show(false)
    
    
//  while(true) {Thread.sleep(10000)}  //--for debug....
    spark.stop()
  }   
  
  case class EventDays(count: Long, page: Long, results: Seq[EventDay], totalResult: Long){}
  case class EventDay(day: String, month: String, name: String, `type`: String, year: String){}  //--스칼라에서는 백틱(`)을 통해 예약어 사용.... ex) myVarialbe.`class`

}