package lab.sql.spark.warehouse
 
/**
 * 
 
 
  1. Spark Shell 연결.... => DF.saveAsTable 테스트 및 파라미터를 사용하여 metastore_db / warehouse dir 위치 설정....
 
  - # ./bin/spark-shell --master spark://CentOS7-14:7077 --executor-memory 512m --total-executor-cores 1 --conf spark.sql.warehouse.dir=/kikang/kikang_warehouse --conf "spark.driver.extraJavaOptions=-Dderby.system.home=/kikang/kikang_metastore_db"
  
  - scala> spark.sql("CREATE TABLE IF NOT EXISTS src3 (key INT, value STRING)")
  
  - scala> spark.sql("LOAD DATA LOCAL INPATH 'examples/src/main/resources/kv1.txt' INTO TABLE src3")
  
  - scala> val df = spark.sql("SELECT * FROM src3")
  
  - scala> df.show
  
  - scala> df.where("key < 100").show
  
  - scala> df.where($"key" < 100).show
  
  - scala> df.where($"key" < 100).write.saveAsTable("src4")
  
  - scala> spark.table("src4").show
  
  - scala> spark.sql("SELECT * FROM src4").show
 
  - # ./bin/spark-shell --master spark://CentOS7-14:7077 --executor-memory 512m --total-executor-cores 1 --conf spark.sql.warehouse.dir=/kikang/kikang_warehouse --conf "spark.driver.extraJavaOptions=-Djavax.jdo.option.ConnectionURL=jdbc:derby:;databaseName=/kikang/kikang_metastore_db/metastore_db;create=true"
     => 예외발생 org.apache.derby.iapi.error.StandardException: Another instance of Derby may have already booted the database /kikang/kikang_metastore_db/metastore_db.
  
  - # ./bin/spark-shell --master spark://CentOS7-14:7077 --executor-memory 512m --total-executor-cores 1 --conf "spark.driver.extraJavaOptions=-Djavax.jdo.option.ConnectionURL=jdbc:derby:;databaseName=/kikang/kikang_metastore_db/metastore_db;create=true"
  	 => 최초 metastore_db 구성시 warehouse.dir가 설정되어 있기 때문에 차후에는 warehouse.dir를 지정할 필요 없음.... 지정하더라도 무시됨....
  
  
  
  2. Spark Shell 연결.... => derby용 hive-site.xml을 사용하여 metastore_db / warehouse dir 위치 설정....
  
  - # vi ./conf/hive-site.xml
  
<!-- derby....-->
<configuration>
   <property>
     <name>javax.jdo.option.ConnectionURL</name>
     <value>jdbc:derby:;databaseName=/kikang/kikang_metastore_db/metastore_db;create=true</value>
     <description>JDBC connect string for a JDBC metastore</description>
   </property>
   <property>
     <name>javax.jdo.option.ConnectionDriverName</name>
     <value>org.apache.derby.jdbc.EmbeddedDriver</value>
     <description>Driver class name for a JDBC metastore</description>
   </property>
   <property>
      <name>hive.metastore.warehouse.dir</name>
      <!--<name>spark.sql.warehouse.dir</name>--> <!-- hive-site.xml용 아님.... spark conf 용임.... -->
      <value>/kikang/kikang_warehouse</value>
      <description>location of default database for the warehouse</description>
   </property>
</configuration>
 
  - # ./bin/spark-shell --master spark://CentOS7-14:7077 --executor-memory 512m --total-executor-cores 1 
  
  - scala> spark.sql("SELECT * FROM src4").show
  
  
  
    
 * 
 */
object SparkShell2 {
  
}