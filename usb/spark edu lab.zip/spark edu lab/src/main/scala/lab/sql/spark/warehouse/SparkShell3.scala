package lab.sql.spark.warehouse
 
/**
 * 
 
 
  1. Spark SQL Shell 연결.... => mysql용 hive-site.xml을 사용하여 metastore_db 구성 및 멀티 세션 연결....
 
  - # vi ./conf/hive-site.xml
  
<!-- mysql....-->
<configuration>
    <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://CentOS7-14:3306/metastore_db?createDatabaseIfNotExist=true</value>
        <description>metadata is stored in a MySQL server</description>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
        <description>MySQL JDBC driver class</description>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>root</value>
        <description>user name for connecting to mysql server </description>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>root</value>
        <description>password for connecting to mysql server </description>
    </property>
    <property>
      	<name>hive.metastore.warehouse.dir</name>
      	<!--<name>spark.sql.warehouse.dir</name>--> <!-- hive-site.xml용 아님.... spark conf 용임.... -->
      	<value>/kikang/kikang_warehouse</value>
      	<description>location of default database for the warehouse</description>
   </property>
</configuration>
 
 
 
  - # mysql 
     => 'root' 계정에 패스워드 'root' 설정....
     
  - mysql> use mysql;
  
  - mysql> SELECT Host,User,Password FROM mysql.user;
  
  - mysql> update user set password=PASSWORD('root') where user='root';  
  
  - mysql> flush privileges;  
  
  - mysql> grant all on *.* to 'root'@'localhost' identified by 'root' with grant option;
  
  - mysql> grant all on *.* to 'root'@'CentOS7-14' identified by 'root' with grant option;
  
  - mysql> grant all on *.* to 'root'@'%' identified by 'root' with grant option;
  
  - mysql> flush privileges;
  
  - mysql> quit;
  
  - # mysqladmin -u root -p shutdown
  
  - # systemctl start mysqld	=> centos6의 경우 # service mysqld start
     
     
     
  - # mysql -uroot -proot
     => 기존에 'metastore_db' 데이터베이스가 있으면 삭제.... 
  
  - mysql> drop database if exists metastore_db;
  
  - mysql> show databases;
  
  
  
  - //--Spark SQL Shell 실행....
  - # ./bin/spark-sql --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077 --executor-memory 512m --total-executor-cores 1
  - # ./bin/spark-sql --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077 --executor-memory 512m --total-executor-cores 1 --driver-class-path mysql-connector-java-5.1.39-bin.jar 
     => mysql-connector-java-5.1.39-bin.jar 가 Spark 홈 디렉터리에 있어야 함....
     => java.sql.SQLException: No suitable driver found for jdbc:mysql://CentOS7-14:3306/metastore_db?createDatabaseIfNotExist=true
     => --jars 옵션이 제대로 동작하지 않을 경우 --driver-class-path 옵션을 이용하여 jdbc 드라이버를 클래스패스에 적용....
     
  - spark-sql> show databases;
  
  - spark-sql> show tables;
  
  - spark-sql> CREATE TABLE IF NOT EXISTS src (key INT, value STRING);
   
  - spark-sql> LOAD DATA LOCAL INPATH 'examples/src/main/resources/kv1.txt' INTO TABLE src;
  
  - spark-sql> SELECT * FROM src;
        
  - mysql> show databases;
     => 'metastore_db' 데이터베이스 생성되어 있음 확인....
  - mysql> use metastore_db;
  - mysql> show tables;
  - mysql> select * from TBLS;
  	 => 'src' 테이블 정보 있음 확인....
  
  
  
  
  - //--Spark Shell 추가 실행....
  - # ./bin/spark-shell --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077 --executor-memory 512m --total-executor-cores 1 
     => 또 다른 Spark Shell 연결 잘 됨.... 
     
  - scala> sql("show tables").show()
  - scala> sc.textFile("README.md").toDS.show()
  - scala> sc.textFile("README.md").toDS.createOrReplaceTempView("readme")
  - scala> sql("show tables").show()
  - scala> sql("select * from readme").show()
  - scala> sc.textFile("README.md").toDS.createOrReplaceGlobalTempView("readmeglobal")
  - scala> sql("show tables").show()
  - scala> sql("select * from global_temp.readmeglobal").show()
  - scala> spark.newSession().sql("show tables").show()
  - scala> spark.newSession().sql("select * from global_temp.readmeglobal").show()
  
  
  
  - //--Spark SQL Shell, Spark Shell 둘 다 종료....
  - spark-sql> quit;
  - scala> :q
  
  
  
  
  
  
  2. Thrift JDBC/ODBC Server 시작....
  
  - # ./sbin/start-thriftserver.sh --jars mysql-connector-java-5.1.39-bin.jar --master spark://CentOS7-14:7077
  
  - # jps		//--SparkSubmit....
  
  - http://192.168.56.114:4040 (=> Thrift JDBC/ODBC Server application UI)
  
  
  
  3. beeline 연결....	=> beeline "2개 이상" 연결....
  
  - # ./bin/beeline
  
  - # jps		//--BeeLine....
  
  - beeline> !connect jdbc:hive2://CentOS7-14:10000
     Enter username for jdbc:hive2://CentOS7-14:10000: kikang		//--kikang2, kikang3 등 username 다르게 입력....
     Enter password for jdbc:hive2://CentOS7-14:10000:							//--공백('') 입력 => 그냥 엔터키....
     
  - 웹 UI "JDBC/ODBC Server" 탭 세션 정보 확인....
  
  0: jdbc:hive2://CentOS7-14:10000> show databases;
  0: jdbc:hive2://CentOS7-14:10000> show tables;
  0: jdbc:hive2://CentOS7-14:10000> select count(*) from src;
  
  - //--Creates or replaces a "persistent view" in default database. The view definition is recorded in the underlying metastore....
  0: jdbc:hive2://CentOS7-14:10000> CREATE OR REPLACE VIEW src_view as select * from src where key < 10;
  0: jdbc:hive2://CentOS7-14:10000> select count(*) from src_view;
  0: jdbc:hive2://CentOS7-14:10000> show tables;
  
  - //--Creates or replaces a "local temporary view"....
  0: jdbc:hive2://CentOS7-14:10000> CREATE OR REPLACE TEMPORARY VIEW src_view_temp as select * from src where key < 20;
  0: jdbc:hive2://CentOS7-14:10000> select count(*) from src_view_temp;
  0: jdbc:hive2://CentOS7-14:10000> show tables;
    
  - //--Creates or replaces a "global temporary view"....
  0: jdbc:hive2://CentOS7-14:10000> CREATE OR REPLACE GLOBAL TEMPORARY VIEW src_view_global_temp as select * from src where key < 30;
  0: jdbc:hive2://CentOS7-14:10000> select count(*) from global_temp.src_view_global_temp;
  0: jdbc:hive2://CentOS7-14:10000> show tables;
  
  - //--SHOW TABLES [{FROM|IN} db_name] [LIKE 'pattern']....
  0: jdbc:hive2://CentOS7-14:10000> show tables;
  0: jdbc:hive2://CentOS7-14:10000> show tables in default;
  0: jdbc:hive2://CentOS7-14:10000> show tables in default like '*view*';
  0: jdbc:hive2://CentOS7-14:10000> show tables in global_temp;
  0: jdbc:hive2://CentOS7-14:10000> show tables in global_temp like '*global*';
  
  
  - //--Creates a "EXTERNAL_TABLE"....#01 (w/ TEXTFILE)....
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS people;
  0: jdbc:hive2://CentOS7-14:10000> 
CREATE EXTERNAL TABLE IF NOT EXISTS people (name STRING, age INT, job STRING)
STORED AS TEXTFILE
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\u003B'
LOCATION '/kikang/kikang_external/people';
//--ROW FORMAT DELIMITED is only compatible with 'textfile', not 'orc'....
//--Unicode code point for 'semicolon(;)' is '\u003B'....
  0: jdbc:hive2://CentOS7-14:10000> show tables;
  mysql> select * from metastore_db.TBLS;
  # ls -al /kikang/kikang_external/people
  0: jdbc:hive2://CentOS7-14:10000> select * from people;
  0: jdbc:hive2://CentOS7-14:10000> LOAD DATA LOCAL INPATH 'examples/src/main/resources/people.csv' INTO TABLE people;
  # ls -al /kikang/kikang_external/people
  0: jdbc:hive2://CentOS7-14:10000> select * from people;
  
  - //--Creates a "EXTERNAL_TABLE"....#02 (w/ ORC)....
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS users_orc;
  0: jdbc:hive2://CentOS7-14:10000> 
CREATE EXTERNAL TABLE IF NOT EXISTS users_orc (name STRING, favorite_color STRING, favorite_numbers ARRAY<INT>)
STORED AS ORC
LOCATION '/kikang/kikang_external/users_orc';
//--ROW FORMAT DELIMITED is only compatible with 'textfile', not 'orc'....
  0: jdbc:hive2://CentOS7-14:10000> show tables;
  mysql> select * from metastore_db.TBLS;
  # ls -al /kikang/kikang_external/users_orc
  0: jdbc:hive2://CentOS7-14:10000> select * from users_orc;
  0: jdbc:hive2://CentOS7-14:10000> LOAD DATA LOCAL INPATH 'examples/src/main/resources/users.orc' INTO TABLE users_orc;
  # ls -al /kikang/kikang_external/users_orc
  0: jdbc:hive2://CentOS7-14:10000> select * from users_orc;
  
  
  - //--Creates a "MANAGED_TABLE"....#01 (w/ INSERT TABLE .... SELECT....)....
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS people_orc;
  0: jdbc:hive2://CentOS7-14:10000> 
CREATE TABLE IF NOT EXISTS people_orc (name STRING, age INT, job STRING)
STORED AS ORC;
	0: jdbc:hive2://CentOS7-14:10000> show tables;
  mysql> select * from metastore_db.TBLS;
	# ls -al /kikang/kikang_warehouse/people_orc
	0: jdbc:hive2://CentOS7-14:10000> select * from people_orc;
	0: jdbc:hive2://CentOS7-14:10000> 
INSERT OVERWRITE TABLE people_orc
SELECT name, age, job
FROM people
WHERE age IS NOT NULL;
	# ls -al /kikang/kikang_warehouse/people_orc
	0: jdbc:hive2://CentOS7-14:10000> select * from people_orc;

	- //--Creates a "MANAGED_TABLE"....#02 (w/ CREATE TABLE .... AS SELECT....)....
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS users_avro;
  0: jdbc:hive2://CentOS7-14:10000> 
CREATE TABLE IF NOT EXISTS users_avro
STORED AS AVRO
AS SELECT * FROM ORC.`examples/src/main/resources/users.orc`;
	0: jdbc:hive2://CentOS7-14:10000> show tables;
  mysql> select * from metastore_db.TBLS;
	# ls -al /kikang/kikang_warehouse/users_avro
	0: jdbc:hive2://CentOS7-14:10000> select * from users_avro;
	
	
	- //--Drop the "EXTERNAL_TABLE"....
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS people;	//--외부(EXTERNAL) 테이블을 삭제하면 데이터는 삭제되지 않고 테이블 정의만 삭제됨....
  # ls -al /kikang/kikang_external/people
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS users_orc;	//--외부(EXTERNAL) 테이블을 삭제하면 데이터는 삭제되지 않고 테이블 정의만 삭제됨....
  # ls -al /kikang/kikang_external/users_orc
  
  - //--Drop the "MANAGED_TABLE"....
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS people_orc;	//--외부(EXTERNAL) 테이블과 달리 내부(MANAGED) 테이블을 삭제하면 기본 데이터도 삭제됨....
  # ls -al /kikang/kikang_warehouse/people_orc
  0: jdbc:hive2://CentOS7-14:10000> DROP TABLE IF EXISTS users_avro;	//--외부(EXTERNAL) 테이블과 달리 내부(MANAGED) 테이블을 삭제하면 기본 데이터도 삭제됨....
  # ls -al /kikang/kikang_warehouse/users_avro
  
    
  - //--Drop the "global temp view", "local temp view" and "persistent view"....
  0: jdbc:hive2://CentOS7-14:10000> DROP VIEW global_temp.src_view_global_temp;
  0: jdbc:hive2://CentOS7-14:10000> show tables in global_temp;
  0: jdbc:hive2://CentOS7-14:10000> DROP VIEW src_view_temp;
  0: jdbc:hive2://CentOS7-14:10000> DROP VIEW src_view;
  0: jdbc:hive2://CentOS7-14:10000> show tables;
  
  
  0: jdbc:hive2://CentOS7-14:10000> !quit
  
  - # jps
  
  - # ls -al /kikang/kikang_warehouse
    
  
    
  4. Thrift JDBC/ODBC Server 종료....
  
  - # ./sbin/stop-thriftserver.sh
  
  - # jps
  
  
  
    
 * 
 */
object SparkShell3 {
  
}