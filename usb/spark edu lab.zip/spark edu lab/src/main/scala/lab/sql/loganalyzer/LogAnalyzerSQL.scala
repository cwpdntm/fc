package lab.sql.loganalyzer

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}

import org.apache.spark.sql.functions._

/**
 * The following log statistics will be computed:
 *   1. The average, min, and max content size of responses returned from the server.
 *   2. A count of response code's returned. (top count 10)
 *   3. All IPAddresses that have accessed this server more than N times. (N == 10) (top count 10)
 *   4. The top endpoints requested by count. (top count 10)
 * 
 */
object LogAnalyzerSQL {
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("LogAnalyzerSQL")
      .config("spark.sql.warehouse.dir", "spark-warehouse")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames
    import spark.implicits._
    
    
    val logFile = "src/main/resources/apache.access.log"
    
    val accessLogs = spark
//    .sparkContext  //--SparkContext....
      .read          //--DataFrameReader....
      .textFile(logFile)
      .map(ApacheAccessLog.parseLogLine)  //--case class 인스턴스 생성....
//    .toDF()
//    .toDS()
    accessLogs.printSchema()
    
    accessLogs.createOrReplaceTempView("accessLogs")
    spark
      .table("accessLogs")
      .cache()
    
      
      
    //--1. The average, min, and max content size of responses returned from the server.
    val contentSizeRow = spark
      .sql("SELECT SUM(contentSize), COUNT(*), MIN(contentSize), MAX(contentSize), AVG(contentSize) FROM accessLogs")
      .first()
    println("1. Content Size Avg: %s, Min: %s, Max: %s"
        .format( 
              contentSizeRow.getLong(0) / contentSizeRow.getLong(1)
            , contentSizeRow(2)
            , contentSizeRow(3) 
        )
    )
    println(s"""1.1 AVG(contentSize) : ${contentSizeRow(4)}""")

    //--DF.describe(cols: String*): DataFrame
    println(s"""1.2 DF.describe("contentSize") : """)
    spark.table("accessLogs").describe("contentSize").show()  //--describe(cols: String*): DataFrame  => Computes basic statistics for numeric and string columns, including count, mean, stddev, min, and max. If no columns are given, this function computes statistics for all numerical or string columns....
    spark.table("accessLogs").describe().show()
    
    //--DF.summary(statistics: String*): DataFrame
    println(s"""1.3 DF.summary("mean") : """)  //--2.3.0 버전부터 지원....
    spark.table("accessLogs").select("contentSize").summary("mean").show()  //--summary(statistics: String*): DataFrame  => Computes specified statistics for numeric and string columns. Available statistics are: - count - mean - stddev - min - max - arbitrary approximate percentiles specified as a percentage (eg, 75%).... If no statistics are given, this function computes count, mean, stddev, min, approximate quartiles (percentiles at 25%, 50%, and 75%), and max.....
    spark.table("accessLogs").summary().show()
    spark.table("accessLogs").summary("count", "mean", "stddev", "min", "5%", "25%", "50%", "75%", "95%", "max").show()
    
    //--percentile_approx(col, percentage [, accuracy]) 
    println(s"""1.4 percentile_approx(col, percentage [, accuracy]) : """)
    spark.sql("select percentile_approx(contentSize, array(0.0, 0.05, 0.25, 0.5, 0.75, 0.95, 1.0)) from accessLogs").show(false)  //--percentile_approx(col, percentage [, accuracy]) - Returns the approximate percentile value of numeric column col at the given percentage. The value of percentage must be between 0.0 and 1.0. The accuracy parameter (default: 10000) is a positive numeric literal which controls approximation accuracy at the cost of memory. Higher value of accuracy yields better accuracy, 1.0/accuracy is the relative error of the approximation....
    spark.table("accessLogs").select(expr("percentile_approx(contentSize, array(0.0, 0.05, 0.25, 0.5, 0.75, 0.95, 1.0))")).show(false)
    
    //--percentile(col, array(percentage1 [, percentage2]...) [, frequency])
    println(s"""1.5 percentile(col, percentage [, frequency]) : """)
    spark.sql("select percentile(contentSize, array(0.0, 0.05, 0.25, 0.5, 0.75, 0.95, 1.0)) from accessLogs").show(false)  //--percentile(col, array(percentage1 [, percentage2]...) [, frequency]) - Returns the exact percentile value array of numeric column col at the given percentage(s). Each value of the percentage array must be between 0.0 and 1.0. The value of frequency should be positive integral....
    spark.table("accessLogs").select(expr("percentile(contentSize, array(0.0, 0.05, 0.25, 0.5, 0.75, 0.95, 1.0))")).show(false)
    
    
    
    
    
     
    //--spark.sql("select ....") => sql("select ....")
    import spark.sql
    
    //--2. A count of response code's returned. (top count 10)
    val responseCodeToCount = sql("SELECT responseCode, COUNT(*) AS total FROM accessLogs GROUP BY responseCode ORDER BY total DESC LIMIT 10")
      .map(row => (row.getInt(0), row.getLong(1)))
      .collect()
    println(s"""2. Response code counts (top 10): ${responseCodeToCount.mkString("[", " , ", "]")}""")

    
    
    

    
    //--3. All IPAddresses that have accessed this server more than N times. (N == 10) (top count 10)
    val ipAddresses = sql("SELECT ipAddress, COUNT(*) AS total FROM accessLogs GROUP BY ipAddress HAVING total > 10 ORDER BY total DESC LIMIT 10")
      .map(row => row.getString(0))
      .collect()
    println(s"""3. IPAddresses > 10 times (top 10): ${ipAddresses.mkString("[", " , ", "]")}""")
    
    
    
    
    
    
    //--4. The top endpoints requested by count. (top count 10)
    val topEndpoints = sql("SELECT endpoint, COUNT(*) AS total FROM accessLogs GROUP BY endpoint ORDER BY total DESC LIMIT 10")
      .map(row => (row.getString(0), row.getLong(1)))
      .collect()
    println(s"""4. Top Endpoints (top 10): ${topEndpoints.mkString("[", " , ", "]")}""")
    
    
    
//  while(true) {Thread.sleep(10000)}  //--for debug.... Driver Web UI > Jobs(DAG)/SQL(DAG,Details:Plans) 
    
    spark.stop()
  }
}
