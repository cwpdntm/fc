package lab.sql.schema

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.sql.types._

object SQLSchema {
  
  def main(args: Array[String]) {
    
    lab.common.config.Config.setHadoopHOME
    
    val spark = SparkSession
      .builder()
      .master("local[2]")
      .appName("SQLSchema")
      .config("spark.sql.warehouse.dir", "spark-warehouse")
      .getOrCreate()
    
    //--For implicit conversions like converting RDDs to DataFrames....
    import spark.implicits._
    
    val eventDayFiles = "src/main/resources/eventday/eventday_*.json"
    
    val eventDayRDD = spark
      .sparkContext	//--SparkContext....
      .wholeTextFiles(eventDayFiles, minPartitions=4)  //--by sc.wholeTextFiles(path: String, minPartitions: Int = defaultMinPartitions): RDD[(String, String)]
      .map(tuple => tuple._2)
    
    val eventDayDS = eventDayRDD.toDS()  //--RDD[String] to Dataset[String].... => by "import spark.implicits._"
    
    eventDayDS.printSchema()
    eventDayDS.show(10, 200)
//  eventDayDS.show(10, 200, true)  //--2.3.0 버전부터 지원.... //--show(numRows: Int, truncate: Int, vertical: Boolean) => vertical : prints output rows vertically (one line per column value).
    
    
    /*
      root
       |-- count: long (nullable = true)
       |-- page: long (nullable = true)
       |-- results: array (nullable = true)
       |    |-- element: struct (containsNull = true)
       |    |    |-- day: string (nullable = true)
       |    |    |-- month: string (nullable = true)
       |    |    |-- name: string (nullable = true)
       |    |    |-- type: string (nullable = true)
       |    |    |-- year: string (nullable = true)
       |-- totalResult: long (nullable = true)
    */
    
    
    //--[Case #1]
    val eventDayDF = spark
      .read              //--infer the input schema automatically from data....
      .json(eventDayDS)  //--read json from Dataset[JSON String].... => json(jsonDataset: Dataset[String]): DataFrame
    
    //--DataFrame....  
    eventDayDF.printSchema()
    eventDayDF.show(5, false)  //--eventDayDF.show() => default 20 rows + strings more than 20 characters will be truncated....
    
    //--DF.map() => return DS.... Encoder for element is required.... 
    val eventDayDFDS01 = eventDayDF.map(x => x)(org.apache.spark.sql.Encoders.kryo[org.apache.spark.sql.Row])  //--Since 1.6.0.... Encoders.kryo[T]: Encoder[T] => Creates an encoder that serializes objects of type T using Kryo. This encoder maps T into a single byte array (binary) field....
    val eventDayDFDS02 = eventDayDF.map(x => x.getAs[Long]("totalResult"))
    eventDayDFDS02.show
    
    //--Dataset.... DF.as[U] => DS[U]....
    val eventDayDFDS = eventDayDF.as[(Long, Long, Array[(String, String, String, String, String)], Long)]
    eventDayDFDS.printSchema()
    eventDayDFDS.show(5, false)
    
    //--DS.map() => return DS.... 
    val eventDayDFDS11 = eventDayDFDS.map(x => x)
    val eventDayDFDS12 = eventDayDFDS.map(x => x._4).toDF("totalResult").as[Long] //--x._4 ("totalResult") is java.lang.Long type....
    eventDayDFDS12.show
    
    
    while(true) {Thread.sleep(10000)}  //--for debug....
    spark.stop()
  }   
  
}